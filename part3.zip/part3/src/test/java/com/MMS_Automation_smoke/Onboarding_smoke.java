package com.MMS_Automation_smoke;



import java.util.Hashtable;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;


import com.MMS_Automation.workflows.Onboarding_Details;
import com.MMS_Automation.workflows.SignInClass;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;


public class Onboarding_smoke  extends Onboarding_Details{

	Logger logger = Logger.getLogger(SignInClass.class.getName());
	
	// working fine after UI changes
	@Test(groups= {"smoke", "functional"}, dataProvider = "getData",enabled=true)
	public void Merchantonboarding_Test(Hashtable <String,String > data) throws Throwable {
		
		try
		{
			boolean result = false;
			
			TestEngine.testDescription.put(HtmlReportSupport.tc_name,"");
			System.out.println("Usertype - "+ data.get("Usertype"));
				 
			SignInClass sign = new SignInClass();
			HtmlReportSupport.reportStep(data.get("TestCoverage"));
		
			SignInClass.specificlogin("makerusername","makerpassword");
			
			result= E2EFlowNewMerchantAddition(data);
			
			sign.logout();

			if (result) 
			{
				Reporter.SuccessReport("MMS merchant onboarding E2E Flow is done. ","Merchant Profile onboarding succesfully done." );
			} 

			else 
			{
				Reporter.failureReport("MMS ", "Merchant Profile onboarding Failed ");
				Assert.assertTrue(result == true, "Test Failed");
			}
		}
			catch (Exception e){
			Reporter.failureReport("MMS", "Merchant Profile onboarding Failed");
			e.printStackTrace();
			Assert.assertTrue(false,"Test Failed");
			
			Reporter.reportStep("Error is:"+e);
		}
		
		
	}
	
	// negative validations
	
	@Test(groups= {"smoke", "functional"}, dataProvider = "getData",enabled=false)
	public void Merchantonboarding_NegativeTest(Hashtable <String,String > data) throws Throwable {
		
		try
		{
			boolean result = false;
			
			TestEngine.testDescription.put(HtmlReportSupport.tc_name,"");
			System.out.println("Usertype - "+ data.get("Usertype"));
				 
			SignInClass sign = new SignInClass();
			HtmlReportSupport.reportStep(data.get("TestCoverage"));
		
			SignInClass.specificlogin("makerusername","makerpassword");
			
			result= E2EFlowNewMerchantAdditionNegative(data);
			
			sign.logout();

			if (result) 
			{
				Reporter.SuccessReport("MMS merchant onboarding E2E Flow is done. ","Merchant Profile onboarding succesfully done." );
			} 

			else 
			{
				Reporter.failureReport("MMS ", "Merchant Profile onboarding Failed ");
				Assert.assertTrue(result == true, "Test Failed");
			}
		}
			catch (Exception e){
			Reporter.failureReport("MMS", "Merchant Profile onboarding Failed");
			e.printStackTrace();
			Assert.assertTrue(false,"Test Failed");
			
			Reporter.reportStep("Error is:"+e);
		}
		
		
	}
}
