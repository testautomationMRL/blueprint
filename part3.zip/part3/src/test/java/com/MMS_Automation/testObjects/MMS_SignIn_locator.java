package com.MMS_Automation.testObjects;

import org.openqa.selenium.By;

public class MMS_SignIn_locator {
	
	
	public static final By Username = By.id("username");
	public static final By Password = By.id("password");
	
	public static final By loginButton = By.xpath("//button[@type='submit']");
	public static final By UserIcon = By.cssSelector("span.fa.fa-user");

}
