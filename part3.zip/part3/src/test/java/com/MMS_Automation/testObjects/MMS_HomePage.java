package com.MMS_Automation.testObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.MainFrameWork.accelerators.ActionEngine;

public class MMS_HomePage extends ActionEngine{
	
	public static WebElement waitforElementToBeClickable(WebElement element,int timeout) {
	    return new WebDriverWait(driver,timeout).until(ExpectedConditions.refreshed(ExpectedConditions.elementToBeClickable(element)));
	}	
	
	public static void scrolltoElement(WebElement element) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		
		js.executeScript("arguments[0].scrollIntoView(true);", element);
		// 
	}
	
	
	public static final By AppNavigator = By.cssSelector(".app-icon.fa.fa-bars");
	public static final By Marketing_link = By.xpath("//span[contains(.,' MARKETING')]");
	//public static final By Leads_link = By.xpath("//span[contains(.,' MARKETING')]");
	public static final By Leads_link = By.xpath("//a[@title='Leads']");
	
	public static final By Merchants_link = By.xpath("//span[contains(.,' Merchants')]");
	public static final By AddLead_btn = By.id("Leads_listView_basicAction_LBL_ADD_RECORD");
	public static final By LeadpopupContinue_btn = By.id("lead_continue");
	
	
	public static final By UserIcon = By.cssSelector("span.fa.fa-user");  
	
	// merchant details
	public static final By AppnSource_drp = By.id("select2-chosen-2");
	public static final By Customer = By.name("customer_display");
	public static final By AppnNumber_txt = By.id("Leads_editView_fieldName_application_no");
	public static final By MerchantDBAname_txt = By.id("Leads_editView_fieldName_merchant_dba_name");
	public static final By MerchantDBAname_err = By.xpath("//div[contains(.,'Special')]");
	//public static final By Aggrgator_txt = By.className("lead_continue");
	//public static final By GroupMerchant_txt = By.id("s2id_autogen3");
	public static final By GroupMerchant_txt = By.cssSelector("input#s2id_autogen3.select2-input");
	
	public static final By ParentMerchant = By.id("Leads_editView_fieldName_parent_merchant_select");
	public static final By ParentMerchantName = By.name("merchantname");
	public static final By ParentMerchantResult = By.xpath("//*[@id='ParentMerchant_popUpListView_row_1']/td[2]/a");
	public static final By MerchantLegalName = By.id("Leads_editView_fieldName_merchant_legal_name");
	public static final By MerchantIdentification = By.id("select2-chosen-7");
	public static final By MerchantIdentificationOldNo = By.id("Leads_editView_fieldName_merchant_identification_old_no");
	public static final By MerchantClassification= By.id("select2-chosen-9");
	
	public static final By CardAcceptance = By.id("select2-chosen-13");
	public static final By AggrementDate = By.id("Leads_editView_fieldName_aggrement_date");
	public static final By MerchantStatus = By.id("select2-chosen-15");
	public static final By NewtotheWorld = By.id("select2-chosen-17");
	public static final By FirmPanNumber = By.id("Leads_editView_fieldName_firm_pan_number");
	public static final By Prefferedlanguage = By.id("select2-chosen-11");
	//public static final By Prefferedlanguage = By.id("select2-chosen-11");
	
	public static final By RMName = By.id("Leads_editView_fieldName_rm_name");
	
	public static final By RMCode = By.id("Leads_editView_fieldName_rm_code");
	public static final By MESegment = By.id("select2-chosen-19");
	public static final By BusinessEntity = By.id("select2-chosen-21");
	public static final By AssignedTo = By.id("select2-chosen-23");
	public static final By MonthlyLimit = By.id("Leads_editView_fieldName_monthly_limit");
	public static final By RiskApprovalWaive = By.id("select2-chosen-25");
	public static final By Mcc  = By.id("Leads_editView_fieldName_mcc_select");
	public static final By MccSearch  = By.name("mcc_code");
	public static final By MccSearchbtn  = By.xpath("//button[contains(.,'Search')]"); 
	public static final By MccSearchResult1  = By.xpath("//*[@id='Mcc_popUpListView_row_1']/td[2]/a");
	
	
	
	public static final By SchemeBacklistCheck  = By.id("select2-chosen-27");
	public static final By Tcc  = By.id("Leads_editView_fieldName_tcc");
	public static final By Bank  = By.id("bank_display");
	public static final By DailyLimit  = By.id("Leads_editView_fieldName_daily_limit");
	public static final By Division  = By.id("division_display");
	public static final By PerTransactionLimit  = By.id("Leads_editView_fieldName_per_txn_limit");
	public static final By FIRCFrequency   = By.id("select2-chosen-29");
	public static final By Branch  = By.id("Leads_editView_fieldName_branch_select"); 
	public static final By BranchCode = By.name("branch_code");
	public static final By BranchSearchbtn  = By.xpath("//button[contains(.,'Search')]"); 
	public static final By BranchSearchResult1  = By.xpath("//*[@id='Branch_popUpListView_row_1']/td[2]/a");
	
	
	public static final By RiskRejected   = By.id("select2-chosen-31");
	public static final By TransactionCurrency   = By.id("select2-chosen-33");
	public static final By AverageMonthlyBalance   = By.id("Leads_editView_fieldName_average_monthly_balance");
	public static final By EcommerceIndicator  = By.id("select2-chosen-35");
	public static final By PromoCode   = By.id("Leads_editView_fieldName_promo_code");
	
	
	//Merchant Address Details - By Abhay Dhamal        
	public static final By MerchantAddressDetailsection = By.xpath("//*[@id='EditView']/div[4]/div/div/div[2]/h4");
    public static final By MerchantAddressLine1 = By.id("Leads_editView_fieldName_merchant_address_line_1");
    public static final By MerchantAddressLine2 = By.id("Leads_editView_fieldName_merchant_address_line_2");
    public static final By CopyMailingAddress = By.xpath("//*[@id='EditView']/div[4]/div/div/div[2]/div/span[1]/div[2]/div/a");
    public static final By MerchantPinCode = By.id("Leads_editView_fieldName_merchant_pin_code_select");
    //public static final By MerchantPinCode1 = By.className("listSearchContributor inputElement"); 
    public static final By MerchantPinCodetype = By.name("pin_code");
    //public static final By SearchPin = By.name("//*[@id='mCSB_7_container']/div/table/tbody/tr[1]/td[1]/button");  
    public static final By SearchPin = By.xpath("//button[contains(.,'Search')]");
    public static final By SelectSearchPin = By.xpath("//*[@id='PinCode_popUpListView_row_1']/td[2]");
    public static final By MerchantRegion = By.id("Leads_editView_fieldName_merchant_region");
    public static final By MerchantTaluk  = By.id("Leads_editView_fieldName_merchant_taluk");
    public static final By MerchantDivision  = By.id("Leads_editView_fieldName_merchant_division");
    public static final By MerchantDistrict  = By.id("Leads_editView_fieldName_merchant_district");
    public static final By MerchantState  = By.id("Leads_editView_fieldName_merchant_state");
    public static final By MerchantCountry  = By.id("Leads_editView_fieldName_merchant_country");
    public static final By PrimaryEmail  = By.id("Leads_editView_fieldName_primary_email");
    public static final By SecondaryEmail   = By.id("Leads_editView_fieldName_secondaryemail");
    public static final By MerchantPanNumber   = By.id("Leads_editView_fieldName_merchant_pan_no");
    public static final By PrimaryContactPerson  = By.id("Leads_editView_fieldName_primary_contact_person");
    public static final By SecondaryMobileNumber   = By.id("Leads_editView_fieldName_secondary_mobile");
    public static final By PrimaryMobileNumber  = By.id("Leads_editView_fieldName_primary_mobile");
    public static final By Landline   = By.id("Leads_editView_fieldName_landline");
    
    public static final By MerchantCity  = By.xpath("//*[@id='Leads_editView_fieldName_merchant_city_select']");
    public static final By MerchantCitytype = By.name("cityname");
    //public static final By Searchcity= By.xpath("//*[@id='mCSB_9_container']/div/table/tbody/tr[1]/td[1]/button");
    public static final By Searchcity= By.xpath("//button[contains(.,'Search')]");
    public static final By SelectSearchcity= By.xpath("//*[@id='City_popUpListView_row_1']/td[2]/a");
	
	
	
	
//Mailing Address Details  - By Arvind Bangar 
    public static final By MailingAddressDetailsection = By.xpath("//*[@id='EditView']/div[4]/div/div/div[3]/h4");
    public static final By MailingAddressLine1   = By.id("Leads_editView_fieldName_mail_address_line_1");
    public static final By MailingAddressLine2   = By.id("Leads_editView_fieldName_mail_address_line_2");
    public static final By CopyMerchantAddress   = By.linkText("Copy Merchant Address");
    //public static final By CopyMerchantAddress   = By.name("copyAddress");
    public static final By MailingPinCode   = By.id("Leads_editView_fieldName_mail_pin_code_select");
    public static final By MailingPinCode1   = By.name("pin_code");
    public static final By ClickSearch   = By.xpath("//button[contains(.,'Search')]");
    public static final By ClickResult   = By.xpath("//*[@id='PinCode_popUpListView_row_1']/td[2]/a");
    public static final By SezFlag   = By.id("select2-chosen-37");
    public static final By ownerName   = By.id("Leads_editView_fieldName_owner_name");
    public static final By OwnerMobileNumber   = By.id("Leads_editView_fieldName_owner_mobline_no");
    public static final By MailCity   = By.id("Leads_editView_fieldName_mail_city_select");
    public static final By CityName   = By.name("cityname");
    public static final By ClickSearch1   = By.xpath("//button[contains(.,'Search')]"); 
    public static final By ClickResult1   = By.xpath("//*[@id='City_popUpListView_row_1']/td[2]/a");
  

    
    
    //payment details
    
    public static final By PaymentType   = By.id("select2-chosen-41");
    public static final By AccountNumber   = By.id("Leads_editView_fieldName_account_number"); 
    public static final By AccountName   = By.id("Leads_editView_fieldName_account_name");
    public static final By PaymentCalculation   = By.id("select2-chosen-43");
    public static final By SettelementCurrency   = By.id("select2-chosen-45");
    public static final By StatementAdviceFormat   = By.id("select2-chosen-47");
    
    //Fee
    public static final By JoiningFee   = By.id("Leads_editView_fieldName_joining_fee");
    public static final By AnnualSetupFee   = By.id("Leads_editView_fieldName_anual_setup_fee");
    public static final By ConvenienceFeeType    = By.id("select2-chosen-49");
    public static final By TPCType   = By.id("select2-chosen-51");
    public static final By TPCValue   = By.id("Leads_editView_fieldName_tpc_value");
    
    
    //convinience fee 
    public static final By convfeeHeader   = By.xpath("//*[@id='EditView']/div[4]/div/div/div[6]/h4");
    public static final By DRmorethan2k   = By.id("Leads_editView_fieldName_dr_mt_2k");
    public static final By DRlessthan2k   = By.id("Leads_editView_fieldName_dr_lt_2k");
    public static final By InternationalCR = By.id("Leads_editView_fieldName_international_cr");
    public static final By DomesticCR   = By.id("Leads_editView_fieldName_domestic_cr");
    public static final By PaymentOfConvenienceFee   = By.id("select2-chosen-53");
    
    //Turnover
    public static final By MonthlyCardVolume   = By.id("Leads_editView_fieldName_monthly_card_volume");
    public static final By ProjectedAvgTicketSize   = By.id("Leads_editView_fieldName_projected_avg_ticket_size");
    public static final By BankExpectedShareperct = By.id("Leads_editView_fieldName_bank_expected_share_percent");
    public static final By BusinessType   = By.id("select2-chosen-55");
    public static final By GSTNumber   = By.id("Leads_editView_fieldName_gst_number");
    
    
    //Asset
    public static final By CommunicationMode   = By.id("select2-chosen-73");
    public static final By AssetType   = By.id("select2-chosen-118");
    public static final By Programs   = By.xpath("//*[contains(@id,'getLeadTerminal_fieldName_lt_program_offered')]/ul");
    public static final By ApplicatioParameter   = By.xpath("//*[contains(@id,'fieldName_application_parameter')]/ul");
    public static final By RentType   = By.id("select2-chosen-79"); 
    public static final By Rent   = By.xpath("//*[contains(@id,'fieldName_rent')]");
    public static final By NoOfTerminal   = By.xpath("//*[contains(@id,'fieldName_terminal_count')]");
    
    //upload
    public static final By Title   = By.id("_editView_fieldName_notes_title");
    public static final By UploadBtn   = By.cssSelector("div.fileUploadBtn.btn.btn-primary");
    public static final By UploadBtnsign   = By.xpath("//*[@id='LeadTermTable']/tfoot/tr/td/i");
    public static final By UploadBtnsign2   = By.cssSelector("//*[@id='LeadTermTable']/tfoot/tr/td/i");
    public static final By DocumentType   = By.id("select2-chosen-165");
    
    
    //comments
    
    public static final By comments   = By.id("Leads_editView_fieldName_lead_comments");
    public static final By savebtn   = By.cssSelector("button.btn.btn-success.saveButton");
    public static final By popupok   = By.xpath("//*[@id='lead_save_popup']/div[2]/div/div[2]/a");
    public static final By popupAppNumber   = By.xpath("//*[@id='lead_save_popup']/div[2]/div/div[1]/b[1]");
    public static final By popupText   = By.xpath("//*[@id='lead_save_popup']/div[2]/div/div[1]");
    
    
    // chekar user homepage
    public static final By chk_LeadNumber   = By.name("lead_no");
    public static final By chk_searchbtn   = By.cssSelector("button.btn.btn-success.btn-sm");
    public static final By chk_searchresult   = By.xpath("//*[@id='Leads_listView_row_1']/td[2]/span[1]/span/a");
    public static final By chk_resultEdit   = By.id("Leads_detailView_basicAction_LBL_EDIT");
    public static final By chk_merchantStatus   = By.id("select2-chosen-15");
    public static final By chk_comments   = By.id("Leads_editView_fieldName_lead_comments");
    public static final By chk_savebtn   = By.cssSelector("button.btn.btn-success.saveButton");
    public static final By chk_modal   = By.cssSelector("div.modal-body.success_msg");
    public static final By chk_modal_ok   = By.cssSelector("a.btn.btn-success");
    
    // risk
    public static final By risk_LeadNumber   = By.name("lead_no");
    public static final By risk_searchbtn   = By.cssSelector("button.btn.btn-success.btn-sm");
    public static final By risk_searchresult   = By.xpath("//*[@id='Leads_listView_row_1']/td[10]/span/span/a");
    public static final By risk_convertLead   = By.id("Leads_detailView_basicAction_LBL_CONVERT_LEAD");
    public static final By risk_convertLeadpopup   = By.id("Leads_detailView_basicAction_LBL_CONVERT_LEAD");
    
    //risk popup
    public static final By risk_Mandatoryfields   = By.id("select2-chosen-14");
    public static final By risk_Bankstatement    = By.id("select2-chosen-16");
    public static final By risk_BLR  = By.id("select2-chosen-18");
    public static final By risk_MerchantAdd   = By.id("select2-chosen-20");
    public static final By risk_SettelementAccount  = By.id("select2-chosen-22"); 
    public static final By risk_RiskWaiver  = By.id("select2-chosen-24"); 
    public static final By risk_RiskmodalCovertBtn  = By.name("saveButton"); 
    
    // risk final modal
    public static final By risk_modalText   = By.xpath("//*[@id='lead_save_popup']/div[2]/div/div[1]");
    public static final By risk_modalOKbtn    = By.name("saveButton"); 
    
    //risk merchant page
    public static final By risk_Mid   = By.name("mid");
    public static final By risk_searchBtn   = By.cssSelector("button.btn.btn-success.btn-sm");
    public static final By risk_Merchantsearchresult   = By.xpath("//*[@id='Accounts_listView_row_1']/td[5]/span[1]/span/a");
    public static final By risk_Mid_txt   = By.name("//*[@id='Accounts_detailView_fieldValue_mid']/span[1]");
    public static final By risk_MerchantNo   = By.xpath("//*[@id='Accounts_detailView_fieldValue_account_no']/span");
    public static final By risk_showmap   = By.linkText("Show Map");
    
 
    //Domestic Debit Card
    public static final By Leads_editView_fieldName_pos_online_non_qr_txn_onus   = By.id("Leads_editView_fieldName_pos_online_non_qr_txn_onus");
    public static final By Leads_editView_fieldName_pos_online_non_qr_txn_offus   = By.id("Leads_editView_fieldName_pos_online_non_qr_txn_offus");
    public static final By Leads_editView_fieldName_qr_code_txn_onus   = By.id("Leads_editView_fieldName_qr_code_txn_onus");
    public static final By Leads_editView_fieldName_qr_code_txn_offus   = By.id("Leads_editView_fieldName_qr_code_txn_offus");
    
    //UPI ( Default)
    public static final By Leads_editView_fieldName_less_than_2k   = By.id("Leads_editView_fieldName_less_than_2k");
    public static final By Leads_editView_fieldName_greater_than_2k   = By.id("Leads_editView_fieldName_greater_than_2k");
    
    //Credit Card Category
    public static final By Leads_editView_fieldName_standard_onus   = By.id("Leads_editView_fieldName_standard_onus");
    public static final By Leads_editView_fieldName_standard_domestic_offus   = By.id("Leads_editView_fieldName_standard_domestic_offus");
    public static final By Leads_editView_fieldName_standard_international_offus   = By.id("Leads_editView_fieldName_standard_international_offus");
    public static final By Leads_editView_fieldName_premium_onus   = By.id("Leads_editView_fieldName_premium_onus");
    public static final By Leads_editView_fieldName_premium_domestic_offus   = By.id("Leads_editView_fieldName_premium_domestic_offus");
    public static final By Leads_editView_fieldName_premium_international_offus   = By.id("Leads_editView_fieldName_premium_international_offus");
    public static final By Leads_editView_fieldName_super_premium_onus   = By.id("Leads_editView_fieldName_super_premium_onus");
    public static final By Leads_editView_fieldName_super_premium_domestic_offus   = By.id("Leads_editView_fieldName_super_premium_domestic_offus");
    public static final By Leads_editView_fieldName_superpremium_int_offus   = By.id("Leads_editView_fieldName_superpremium_int_offus");
    

  //*[contains(@id,'message')]
}
