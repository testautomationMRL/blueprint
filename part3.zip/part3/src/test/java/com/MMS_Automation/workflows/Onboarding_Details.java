package com.MMS_Automation.workflows;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;

import com.MMS_Automation.testObjects.MMS_HomePage;
import com.MMS_Automation.testObjects.MMS_SignIn_locator;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;


public class Onboarding_Details extends ActionEngine {

	
	public static boolean E2EFlowNewMerchantAddition(Hashtable <String,String > data) throws Throwable{
		
		boolean result = false;
		
		
		ImplicitWait();
		HtmlReportSupport.reportStep("New Merchant Addition");
		HtmlReportSupport.reportStep("TC_0003:To Check New Merchant Onboarding");
		
		ClickAppNavigator(driver, data);
		
		
		String MerchantIdentification = data.get("CardNumber");
		System.out.println("Value is"+MerchantIdentification);
		HoverMarketingToSelect(driver, data, "Leads");
		
		AddLead(driver, data);
		
		ChekarApproval(driver, data);
		
		RiskApproval(driver, data);
		
		result= verifyLeadcreated(driver, data);
		
		return result;
	}
	
	
public static boolean E2EFlowNewMerchantAdditionNegative(Hashtable <String,String > data) throws Throwable{
		
		boolean result = false;
		
		
		ImplicitWait();
		HtmlReportSupport.reportStep("New Merchant Addition");
		HtmlReportSupport.reportStep("TC_0003:To Check New Merchant Onboarding");
		
		ClickAppNavigator(driver, data);
		
		
		String MerchantIdentification = data.get("CardNumber");
		System.out.println("Value is"+MerchantIdentification);
		HoverMarketingToSelect(driver, data, "Leads");
		
		AddLeadNegative(driver, data);
		
		//ChekarApproval(driver, data);
		
		//RiskApproval(driver, data);
		
		//result= verifyLeadcreated(driver, data);
		
		return result;
	}
	
	
	public static boolean verifyLeadcreated(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
		boolean result = false;
		ClickAppNavigator(driver, data);
		HoverMarketingToSelect(driver, data, "Merchants");
		
		String MID=configProps.getProperty("MID");
		String parentname=data.get("ParentMerchant");
		
		if (waitForElementPresent(MMS_HomePage.risk_Mid,"Lead Number field Present")) {
			type(MMS_HomePage.risk_Mid, MID, "MID");
			waitForElementPresent(MMS_HomePage.risk_searchBtn,"Lead Number field Present");
			click(MMS_HomePage.risk_searchBtn,"Search button Clicked Successfully");
			Thread.sleep(2000);
			waitForElementPresent(MMS_HomePage.risk_Merchantsearchresult,"Lead Number field Present");
			click(MMS_HomePage.risk_Merchantsearchresult,"Result Clicked Successfully");
			waitForPageLoaded();
			waitForElementPresent(MMS_HomePage.risk_showmap,"Lead Number field Present");
			
			String Mid= driver.findElement(By.xpath("//*[@id='Accounts_detailView_fieldValue_mid']/span[1]")).getText();
			String MerchantNumber=	driver.findElement(By.xpath("//*[@id='Accounts_detailView_fieldValue_account_no']/span")).getText();
			
			if(Mid.equals(MID)) {
				
				Reporter.reportStep("MID found. MID is "+Mid);
				Reporter.SuccessReport("MID found in Merchant section.", "MID found in Merchant section");
				result= true;
			}else {
				Reporter.failureReport("MID in Merchant section", "MID search in merchant section failed.");
			}
			
			// parent validation
			
			
			
			
			if(parentname.length()>0) {                              
				String parent= driver.findElement(By.xpath("//*[@id='Accounts_detailView_fieldValue_parent_merchant']/span[1]/p")).getText();
				
				if(parent.equalsIgnoreCase(parentname)) {
					Reporter.SuccessReport("Parent Merchant Name in Merchant section.", "Parent Merchant Name found in Merchant section");
					result= true;
				}else {
					Reporter.failureReport("Parent Merchant Name in Merchant section", "Parent Merchant Name not found in Merchant section.");
				}
				
			}
			
		}
		
		
		return result;
	}


	public static void ChekarApproval(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
		SignInClass sign = new SignInClass();
		HtmlReportSupport.reportStep("Chekar Approval");
		
		String leadnumber=configProps.getProperty("LeadNumber");
		SignInClass.specificlogin("checkerusername","checkerpassword");
		
		ClickAppNavigator(driver, data);
		
		HoverMarketingToSelect(driver, data, "Leads");
		
		if (waitForElementPresent(MMS_HomePage.chk_LeadNumber,"Lead Number field Present")) {

			Reporter.SuccessReport("Merchant Chekar Login"," Passed  ");
			
			type(MMS_HomePage.chk_LeadNumber, leadnumber, "Lead number");
			click(MMS_HomePage.chk_searchbtn,"Search button Clicked Successfully");
			Thread.sleep(3000);
			waitForElementPresent(MMS_HomePage.chk_searchresult,"Checker search result Present");
			
			String state= driver.findElement(By.xpath("//*[@id='listview-table']/tbody/tr/td[8]/span[1]/span/span")).getText();
			String leadnum= driver.findElement(By.xpath("//*[@id='listview-table']/tbody/tr/td[4]/span[1]/span/a")).getText();
			if(state.contains("Application Sent for Checker Approval")&& leadnum.equals(leadnumber) ) {
				Reporter.SuccessReport("Merchant Chekar Search Suceesful."," Passed  ");
				click(MMS_HomePage.chk_searchresult,"Result Clicked Successfully");
			}else {
				Reporter.failureReport("Merchant Chekar Search Unsuceesful."," Fail  ");
			}
			
			if(waitForElementPresent(MMS_HomePage.chk_resultEdit,"Checker search result Present")) {
				click(MMS_HomePage.chk_resultEdit,"Edit Clicked Successfully");
			}
			
			waitForElementPresent(MMS_HomePage.chk_merchantStatus,"Merchant status field Present");
			click(MMS_HomePage.chk_merchantStatus,"MerchantStatus Clicked Successfully");
			
			// approve 
			
			Thread.sleep(2000);
			
			List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
			  
				  for(WebElement e: dropdown) {
				  String a = e.getText();
				      if(a.contains("Application Approved At Checker")) {
				    	  e.click();
				    	  Reporter.reportStep("Application Approved At Checker selected in dropdown");
				    	  break;
				      }
				  }
					
				  Actions  action=new Actions(driver);
					
				  action.moveToElement(driver.findElement(By.id("Leads_editView_fieldName_lead_comments"))).doubleClick().perform();
				 
				  waitForElementPresent(MMS_HomePage.chk_comments,"Comments field Present");  
				  type(MMS_HomePage.chk_comments, "Automation comments for checker", "Comments");
				  waitForElementPresent(MMS_HomePage.chk_savebtn,"Save button field Present");
				  click(MMS_HomePage.chk_savebtn,"Save button Clicked Successfully");
				  
				  Thread.sleep(2000);
				  waitForElementPresent(MMS_HomePage.chk_modal,"Modal Present");
				  String text= driver.findElement(By.cssSelector("div.modal-body.success_msg")).getText();
				  
				  Reporter.reportStep("Message on the popup is "+text);
				  System.out.println(text);
				  String[] splitStr = text.split("\\s+");
				  
				  if(text.contains("Successfully")) {
					  Reporter.SuccessReport("Lead Approval", "Lead Approval done succesfully.");
				  }else {
					  Reporter.failureReport("Lead Approval", "Lead Approval unsuccesful.");
				  }
				  
				  waitForElementPresent(MMS_HomePage.chk_modal_ok,"Modal OK button Present");
				  click(MMS_HomePage.chk_modal_ok,"Ok button Clicked Successfully");
		}
		
		Thread.sleep(2000);
		SignInClass.logout();
	}


	public static void RiskApproval(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable 
	{
		// TODO Auto-generated method stub
		
		HtmlReportSupport.reportStep("Chekar Approval");
		
		String leadnumber=configProps.getProperty("LeadNumber");
		SignInClass.specificlogin("riskusername","riskuserpassword");
		
			String Mandatoryfields = data.get("Mandatoryfields");
			String BLRdocument = data.get("BLRdocument");
			String AddressProof = data.get("AddressProof");
			String BankStatement = data.get("BankStatement");
			String SettelementAccount = data.get("SettelementAccount");
			String RiskWaiver = data.get("RiskWaiver");
			
			ClickAppNavigator(driver, data);
		
			HoverMarketingToSelect(driver, data, "Leads");
		
			if (waitForElementPresent(MMS_HomePage.risk_LeadNumber,"Lead Number field Present")) 
			{
				Reporter.SuccessReport("Risk Login"," Passed  ");
			
				type(MMS_HomePage.risk_LeadNumber, leadnumber, "Lead number");
				click(MMS_HomePage.risk_searchbtn,"Search button Clicked Successfully");
				waitForElementPresent(MMS_HomePage.risk_searchresult,"Risk search result Present");
			
				String state= driver.findElement(By.xpath("//*[@id='Leads_listView_row_1']/td[3]/span[1]/span/span")).getText();
				String leadnum= driver.findElement(By.xpath("//*[@id='Leads_listView_row_1']/td[10]/span/span/a")).getText();
					if(state.contains("Waiting For Risk Approval")&& leadnum.equals(leadnumber) ) {
						Reporter.SuccessReport("Merchant risk Search Suceesful."," Passed  ");
						Thread.sleep(2000);
						click(MMS_HomePage.risk_searchresult,"Result Clicked Successfully");
					}else {
						Reporter.failureReport("Merchant risk Search Unsuceesful."," Fail  ");
					}
			}
			
			if(waitForElementPresent(MMS_HomePage.risk_convertLead,"Risk search result Present")) 
			{
				click(MMS_HomePage.risk_convertLead,"Covert Lead Clicked Successfully");
			}
			
			
			if(waitForElementPresent(MMS_HomePage.risk_convertLead,"Convert lead popup button Present")) 
			{
				
				// click all dropdown
				
				try {
					
					if(Mandatoryfields.length()>0){
						 Thread.sleep(2000);
							driver.findElement(By.xpath("//*[@id='leadAccordion1']/table/tbody/tr[1]/td[2]/div")).click();
						
							Thread.sleep(2000);
							
							  List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
						  
							  for(WebElement e: dropdown) {
							  String a = e.getText();
							      if(a.contains("Yes")) {
							    	  e.click();
							    	  break;
							      }
							  }
						}
					
					//Owner Documents – ID & Bank Statement – uploaded?
					
					if(BankStatement.length()>0){
						 Thread.sleep(2000);
						driver.findElement(By.xpath("//*[@id='leadAccordion1']/table/tbody/tr[2]/td[2]/div")).click();
							//waitForElementPresent(MMS_HomePage.risk_Bankstatement,"BLRdocument field Present");
							//click(MMS_HomePage.risk_Bankstatement,"BLRdocument clicked.");
								  
							Thread.sleep(2000);
									 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
							List<WebElement> dropdown2= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
								  
							for(WebElement e: dropdown2) {
								String a = e.getText();
									 if(a.contains(BankStatement)) {
									    e.click();
									     break;
									      }
								}
						}
					
					
					//Has Legal / BLR documents uploaded?
					if(BLRdocument.length()>0){
						Thread.sleep(2000);
						driver.findElement(By.xpath("//*[@id='leadAccordion1']/table/tbody/tr[3]/td[2]/div")).click();
						
						Thread.sleep(2000);
										  // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
						List<WebElement> dropdown3= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));

						for(WebElement e: dropdown3) {
							String a = e.getText();
							if(a.contains(BLRdocument)) {
								e.click();
								break;
								}
							}
					  }
						
						//Has Merchant Address proof documents been upload?

						if(AddressProof.length()>0){
						
							Thread.sleep(2000);
							driver.findElement(By.xpath("//*[@id='leadAccordion1']/table/tbody/tr[4]/td[2]/div")).click();

							Thread.sleep(2000);
											 
							List<WebElement> dropdown4= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));

							for(WebElement e: dropdown4) {
								String a = e.getText();
								if(a.contains(AddressProof)) {
									e.click();
									break;
									}
								}
						     }
						
				//Has Settlement Account bank statement been uploaded?
						if(SettelementAccount.length()>0){
						
							Thread.sleep(2000);
							driver.findElement(By.xpath("//*[@id='leadAccordion1']/table/tbody/tr[5]/td[2]/div")).click();

							Thread.sleep(2000);
											  
							List<WebElement> dropdown5= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));

							for(WebElement e: dropdown5) {
								String a = e.getText();
								if(a.contains(SettelementAccount)) {
									e.click();
									break;
									}
								}
						    }
						/*	
							//Has Risk Waiver document been uploaded?			
							if(RiskWaiver.length()>0){
							
								Thread.sleep(2000);
								driver.findElement(By.xpath("//*[@id='leadAccordion1']/table/tbody/tr[6]/td[2]/div")).click();

								Thread.sleep(2000);
												  // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
								List<WebElement> dropdown6= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));

								for(WebElement e: dropdown6) {
									String a = e.getText();
									if(a.contains(RiskWaiver)) {
										e.click();
										break;
										}
									}
							   }
							*/
				}catch(Exception e) {
					
				}
						  Thread.sleep(2000);
						  
						  driver.findElement(By.xpath("//*[@id='convertLeadForm']/div[2]/center/button/strong")).click();
						  Thread.sleep(3000);
						  String text= driver.findElement(By.xpath("//*[@id='lead_save_popup']/div[2]/div/div[1]")).getText();
						  
						  String[] splitStr = text.split("\\s+");
						  
						  String mid=splitStr[1];
						  Reporter.reportStep("MID captured from application is :"+mid);
						  configProps.setProperty("MID",mid);
						  
						  if(text.contains("has been Created Successfully")) {
							  Reporter.SuccessReport("Lead Approval", "Risk Approval done succesfully.");
							  
							  driver.findElement(By.xpath("//*[@id='lead_save_popup']/div[2]/div/div[2]/a")).click();
								
						  }else {
							  Reporter.failureReport("Lead Approval", "Risk Approval unsuccesful.");
						  }
						  
						  Thread.sleep(2000);
					}
						
	}


	public static void ClickAppNavigator(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {

		if (waitForElementPresent(MMS_HomePage.AppNavigator,"App Navigator Present")) {

			Reporter.SuccessReport("Merchant Onboarding Link Present. "," Passed  ");
			click(MMS_HomePage.AppNavigator,"App Navigator Clicked Successfully");

		}
	}
	
	public static void HoverMarketingToSelect(EventFiringWebDriver driver, Hashtable<String, String> data, String section) throws Throwable {

		
		if (waitForElementPresent(MMS_HomePage.Marketing_link,"Marketing Link Present")) {

			Reporter.SuccessReport("Marketing Link Present Present."," Passed");
			

		}
		
		
		if(mouseover(MMS_HomePage.Marketing_link,"Marketing Hover over")) {
			Thread.sleep(2000);
			waitForElementPresent(MMS_HomePage.Leads_link, "Leads link visible.");
			// click Leads, merchant section
			if(section.contains("Leads")) {
				click(MMS_HomePage.Leads_link,"Leads link Clicked Successfully");

			}else if(section.contains("Merchants")) {
				click(MMS_HomePage.Merchants_link,"Merchants link Clicked Successfully");
			}
			
		}
	}
	
	
	public static void AddLead(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		
		//Add lead
		Reporter.reportStep("Add lead section");
		if (waitForElementPresent(MMS_HomePage.AddLead_btn,"Add Lead button Present"))
		{
			
			click(MMS_HomePage.AddLead_btn,"Continue button on popup clicked successfully");
			waitForPageLoaded();
			waitForVisibilityOfElement(MMS_HomePage.LeadpopupContinue_btn,"Continue button on popup Present");
			click(MMS_HomePage.LeadpopupContinue_btn,"Continue button on popup clicked successfully");
			
		}
		fillMerchantDetails(driver, data);
		
		fillMerchantAddressDetails(driver, data);
		
		fillMailingAddress(driver, data);
		
		fillPaymentDetails(driver, data);
		
		fillFeeProgramDetails(driver, data);
		
		fillConvenienceFeeDetails(driver, data);
		
		fillTurnoverProjectionDetails(driver, data);
		
		fillDomesticDebitCardDetails(driver, data);
		
		fillUPIDefaultDetails(driver, data);
		
		fillCreditCardCategoryDetails(driver, data);
		
		fillAssetDetails(driver, data);
		
		uploadDocument(driver, data);
		
		fillComments(driver, data);
		
		clickSave();
		
		SignInClass.logout();
//		
		  
	}
	
public static void AddLeadNegative(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		
		//Add lead
		Reporter.reportStep("Add lead section");
		if (waitForElementPresent(MMS_HomePage.AddLead_btn,"Add Lead button Present"))
		{
			
			click(MMS_HomePage.AddLead_btn,"Continue button on popup clicked successfully");
			waitForPageLoaded();
			waitForVisibilityOfElement(MMS_HomePage.LeadpopupContinue_btn,"Continue button on popup Present");
			click(MMS_HomePage.LeadpopupContinue_btn,"Continue button on popup clicked successfully");
			
		}
	//	fillMerchantDetailsNegative(driver, data);
		
		//fillMerchantAddressDetails(driver, data);
		
		//fillMailingAddress(driver, data);
		
		//fillPaymentDetails(driver, data);
		
		//fillFeeProgramDetails(driver, data);
		
		//fillConvenienceFeeDetails(driver, data);
		
		//fillTurnoverProjectionDetails(driver, data);
		
		//fillDomesticDebitCardDetails(driver, data);
		
		//fillUPIDefaultDetails(driver, data);
		
		//fillCreditCardCategoryDetails(driver, data);
		
		//fillAssetDetails(driver, data);
		
		//uploadDocument(driver, data);
		
		//fillComments(driver, data);
		
		//clickSave();
		
		SignInClass.logout();
//		
		  
	}
	
	


	public static void uploadDocument(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
		String UploadDocumentTitle = data.get("UploadDocumentTitle");
		String DocumentType = data.get("DocumentType");
		
		Reporter.reportStep("Document Section");
		Thread.sleep(2000);
		scrollDown();
		
		// new code arvind
		try {
			if(driver.findElements(By.xpath("//*[@id='documents_table']/tbody/tr")).size()>0) {
				
				List<WebElement> textbox = driver.findElements(By.id("_editView_fieldName_notes_title")); 
				
				for(WebElement elem: textbox){
					elem.sendKeys(UploadDocumentTitle);
			
				}
				
				List<WebElement> uploads = driver.findElements(By.cssSelector("div.fileUploadBtn.btn.btn-primary")); 
				
				for(WebElement elem: uploads){
				
					String master = driver.getWindowHandle();
					elem.click();
					Thread.sleep(2000);	
					String projectPath = System.getProperty("user.dir");
				    String PathTofile = "\\src\\test\\java\\com\\MMS_Automation\\data\\sample.pdf";
				    String path = projectPath + PathTofile;
				 
				    StringSelection ss = new StringSelection(path);
				    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
				    
				    Robot robot = new Robot();

				    robot.keyPress(KeyEvent.VK_CONTROL);
				    robot.keyPress(KeyEvent.VK_V);
				    robot.keyRelease(KeyEvent.VK_V);
				    robot.keyRelease(KeyEvent.VK_CONTROL);
				    robot.keyPress(KeyEvent.VK_ENTER);
				    robot.keyRelease(KeyEvent.VK_ENTER);
				    
				}
				
			}
			
		}catch (Exception e) {
			
			List<WebElement> btns= driver.findElements(By.cssSelector("i.fa.fa-plus"));
			
			btns.get(2).click();
			Thread.sleep(2000);
		
			// DocumentType 
					 if(DocumentType.length()>0){
						  waitForElementPresent(MMS_HomePage.DocumentType,"DocumentType Present");
						  click(MMS_HomePage.DocumentType,"DocumentType field clicked");
						  Thread.sleep(2000);
						
						  List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
						  for(WebElement e1: dropdown) {
						  String a = e1.getText();
						      if(a.contains(DocumentType)) {
						    	  e1.click();
						    	  Reporter.reportStep("DocumentType selected as :"+DocumentType);
						    	  break;
						      }
						  }
					 }	
					 
			waitForElementPresent(MMS_HomePage.Title,"Title Present");
			type(MMS_HomePage.Title, UploadDocumentTitle, "Title");
			
			waitForElementPresent(MMS_HomePage.UploadBtn,"Upload button Present");
			String master = driver.getWindowHandle();
			click(MMS_HomePage.UploadBtn, "Upload button clicked.");
			Thread.sleep(3000);	
			
		    String projectPath = System.getProperty("user.dir");
		    String PathTofile = "\\src\\test\\java\\com\\MMS_Automation\\data\\sample.pdf";
		    String path = projectPath + PathTofile;
		  
		    StringSelection ss = new StringSelection(path);
		    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
		    
		    Robot robot = new Robot();

		    robot.keyPress(KeyEvent.VK_CONTROL);
		    robot.keyPress(KeyEvent.VK_V);
		    robot.keyRelease(KeyEvent.VK_V);
		    robot.keyRelease(KeyEvent.VK_CONTROL);
		    robot.keyPress(KeyEvent.VK_ENTER);
		    robot.keyRelease(KeyEvent.VK_ENTER);    
			
		}
		
	}


	public static void clickSave() throws Throwable {
		// TODO Auto-generated method stub
		waitForElementPresent(MMS_HomePage.savebtn,"savebtn Present");
		click(MMS_HomePage.savebtn, "save button clicked.");
		//add wait for page load
		Thread.sleep(2000);
		waitForElementPresent(MMS_HomePage.popupok,"savebtn Present");
		Thread.sleep(2000);
		
		String text= driver.findElement(By.xpath("//*[@id='lead_save_popup']/div[2]/div/div[1]")).getText();
		String appNumber=driver.findElement(By.xpath("//*[@id='lead_save_popup']/div[2]/div/div[1]/b[1]")).getText();
		System.out.println("app number is:"+appNumber);
		configProps.setProperty("LeadNumber",appNumber);
		System.out.println("text is:"+text);
		Reporter.reportStep("Message from the application is:"+text);
		click(MMS_HomePage.popupok, "Ok button clicked on pop up.");
	}


	public static void fillComments(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
		String comments = data.get("comments");
		
		Actions  action=new Actions(driver);
		Reporter.reportStep("Comments Section");
		action.moveToElement(driver.findElement(By.id("Leads_editView_fieldName_super_premium_domestic_offus"))).click().perform();
		scrollDown();
		waitForElementPresent(MMS_HomePage.comments,"comments Present");
		type(MMS_HomePage.comments, comments, "comments");
	}


	public static void fillAssetDetails(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
		
		String CommunicationMode = data.get("CommunicationMode");
		String AssetType = data.get("AssetType"); 
		String Programs = data.get("Programs");
		String ApplicationParameters = data.get("ApplicationParameters");
		String RentType = data.get("RentType");
		String Rent = data.get("Rent");
		String NumberOfTerminal = data.get("NumberOfTerminal");
		
		Actions  action=new Actions(driver);
		
		Reporter.reportStep("Asset Section");
		
		action.moveToElement(driver.findElement(By.id("Leads_editView_fieldName_super_premium_domestic_offus"))).click().perform();
		scrollDown();
		scrollDown();
		
		
		// communication mode
		 if(CommunicationMode.length()>0){
			 Thread.sleep(2000);
			 waitForVisibilityOfElement(By.xpath("//*[@id='row_num1']/td[2]/div/a"), "dropdown");
			 driver.findElement(By.xpath("//*[@id='row_num1']/td[2]/div/a")).click();
			
			  Thread.sleep(2000);
			
			  List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
		  
			  for(WebElement e: dropdown) {
			  String a = e.getText();
			      if(a.contains(CommunicationMode)) {
			    	  e.click();
			    	  Reporter.reportStep("CommunicationMode selected as :"+CommunicationMode);
			    	  break;
			      }
			  }
				
			 Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id='EditView']/div[4]/div/div/div[12]/h4")).click();
			
		  }	
		
		// asset type
				 if(AssetType.length()>0){
					 
					  Thread.sleep(2000);
					  driver.findElement(By.xpath("//*[@id='row_num1']/td[3]/div/a")).click();
					
					  Thread.sleep(2000);
					 
					  List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
				  
					  for(WebElement e: dropdown) {
					  String a = e.getText();
					      if(a.contains(AssetType)) {
					    	  e.click();
					    	  Reporter.reportStep("AssetType selected as :"+AssetType);
					    	  Reporter.SuccessReport("AssetType Validations", "AssetType Validations pass.");
					    	  Reporter.reportStep("TestCase pass: TC116 ");
					    	  break;
					      }
					  }
						
					  Thread.sleep(1000);
					  driver.findElement(By.xpath("//*[@id='EditView']/div[4]/div/div/div[12]/h4")).click();
					
				  }	
				 
				 
				// Programs
				 if(Programs.length()>0){
					
					  Thread.sleep(2000);
					  driver.findElement(By.xpath("//*[@id='row_num1']/td[4]/div/ul")).click();
					 
					  List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
				  
					  for(WebElement e: dropdown) {
					  String a = e.getText();
					      if(a.contains(Programs)) {
					    	  e.click();
					    	  Reporter.reportStep("Programs selected as :"+Programs);
					    	  break;
					      }
					  }
						
					  Thread.sleep(1000);
					  driver.findElement(By.xpath("//*[@id='EditView']/div[4]/div/div/div[12]/h4")).click();
					
				  }	
		
				// ApplicationParameters
				 if(ApplicationParameters.length()>0){
					
					  Thread.sleep(2000);
					  driver.findElement(By.xpath("//*[@id='row_num1']/td[5]/div")).click();
					  driver.findElement(By.xpath("//*[@id='row_num1']/td[5]/div/ul")).click();
					 
					  Thread.sleep(2000);
					 
					  List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
				  
					  for(WebElement e: dropdown) {
					  String a = e.getText();
					      if(a.contains(ApplicationParameters)) {
					    	  e.click();
					    	  Reporter.reportStep("ApplicationParameters selected as :"+ApplicationParameters);
					    	  break;
					      }
					  }
						
					  Thread.sleep(1000);
						driver.findElement(By.xpath("//*[@id='EditView']/div[4]/div/div/div[12]/h4")).click();
					
				  }	
		
				 
				// Renttype
				 if(RentType.length()>0){
					
					 Thread.sleep(2000);
					  driver.findElement(By.xpath("//*[@id='row_num1']/td[6]/div/a")).click();
					  Thread.sleep(2000);
					
					  List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
				  
					  for(WebElement e: dropdown) {
					  String a = e.getText();
					      if(a.contains(RentType)) {
					    	  e.click();
					    	  Reporter.reportStep("RentType selected as :"+RentType);
					    	  break;
					      }
					  }
						
					  Thread.sleep(1000);
					  driver.findElement(By.xpath("//*[@id='EditView']/div[4]/div/div/div[12]/h4")).click();
					
				  }	
		
				//rent
					if (Rent.length()>0){
				          waitForElementPresent(MMS_HomePage.Rent,"Rent field Present");
				          type(MMS_HomePage.Rent, Rent, "Rent"); 
				          Reporter.reportStep("TestCase covered: TC118");
				    	  Reporter.SuccessReport("Rent Validations", "Rent Validations pass.");
				          Thread.sleep(1000);
				          driver.findElement(By.xpath("//*[@id='EditView']/div[4]/div/div/div[12]/h4")).click();
				        
				   }
		
					//NumberOfTerminal
					if (NumberOfTerminal.length()>0){
				          waitForElementPresent(MMS_HomePage.NoOfTerminal,"Rent field Present");
				          type(MMS_HomePage.NoOfTerminal, NumberOfTerminal, "NumberOfTerminal");
				          Reporter.reportStep("TestCase covered: TC117");
				    	  Reporter.SuccessReport("NoOfTerminal Validations", "NoOfTerminal Validations pass.");
				          Thread.sleep(1000);
				          driver.findElement(By.xpath("//*[@id='EditView']/div[4]/div/div/div[12]/h4")).click();
				   }
		
	}


	public static void fillTurnoverProjectionDetails(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
		
		String MonthlyCardVolume = data.get("MonthlyCardVolume");
		String ProjectedAvgTicketSize = data.get("ProjectedAvgTicketSize"); 
		String BankExpectedShareperct = data.get("BankExpectedShareperct");
		String BusinessType = data.get("BusinessType");
		String GSTNumber = data.get("GSTNumber ");
		
		Reporter.reportStep("Turnover Projections");
		Actions  action=new Actions(driver);
		
		action.moveToElement(driver.findElement(By.id("Leads_editView_fieldName_international_cr"))).doubleClick().perform();
		//scrollDown();
		
		//monthly crad volume
		if (MonthlyCardVolume.length()>0){
	          waitForElementPresent(MMS_HomePage.MonthlyCardVolume,"MonthlyCardVolume Present");
	          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
	          type(MMS_HomePage.MonthlyCardVolume, MonthlyCardVolume, "MonthlyCardVolume");
	        
	   }
		
		//projected average ticket size
		if (ProjectedAvgTicketSize.length()>0){
			          waitForElementPresent(MMS_HomePage.ProjectedAvgTicketSize,"ProjectedAvgTicketSize Present");
			          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
			          type(MMS_HomePage.ProjectedAvgTicketSize, ProjectedAvgTicketSize, "ProjectedAvgTicketSize");
			        
			   }
		
		//BankExpectedShareperct
		if (BankExpectedShareperct.length()>0){
	          waitForElementPresent(MMS_HomePage.BankExpectedShareperct,"BankExpectedShareperct Present");
	          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
	          type(MMS_HomePage.BankExpectedShareperct, BankExpectedShareperct, "BankExpectedShareperct");
	        
	   }
		
		//GST
				if (GSTNumber.length()>0){
			          waitForElementPresent(MMS_HomePage.GSTNumber,"GSTNumber Present");
			          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
			          type(MMS_HomePage.GSTNumber, GSTNumber, "GSTNumber");
			          Reporter.reportStep("TestCase TC21 pass.");
			          Reporter.SuccessReport("GSTN validation", "GSTN field present.");
			   }
				
		// business type
				 if(BusinessType.length()>0){
					  waitForElementPresent(MMS_HomePage.BusinessType,"BusinessType Present");
					  click(MMS_HomePage.BusinessType,"BusinessType field clicked");
					  Thread.sleep(2000);
					 
					  List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
				  
					  ArrayList<String> arr = new ArrayList<String>();
					  
					   for(WebElement e: dropdown) {
							  String a = e.getText();
							  arr.add(a);
							  
							  }
					  
					  
					  
					  for(WebElement e: dropdown) {
					  String a = e.getText();
					      if(a.contains(BusinessType)) {
					    	  e.click();
					    	  Reporter.reportStep("BusinessType selected as :"+BusinessType);
					    	  break;
					      }
					  }
					  
					  if(arr.contains("Small") && arr.contains("Other Merchants")) {
						  Reporter.SuccessReport("BusinessType validations", "BusinessType validations pass.");
						  Reporter.reportStep("BusinessType dropdown contains Small, Other Merchants options.");
						  Reporter.reportStep("TC 111 Pass.");
					  }else {
						  Reporter.failureReport("BusinessEntity", "BusinessEntity validations failed.");
						  Reporter.reportStep("TC 111 Fail.");
					  }
					  
					  Reporter.reportStep("Turnover details Option");
					  Reporter.reportStep("TC 110 Pass.");
					  Reporter.SuccessReport("Turnover details Option validations", "Turnover details Option validations Pass");
					  System.out.println("Lead Page is having Turnover details Option to enter details");
					  
					 
					action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 }	
				 
	}


	public static void fillConvenienceFeeDetails(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
		
		String DRmorethan2k = data.get("DRmorethan2k");
		String DRlessthan2k = data.get("DRlessthan2k"); 
		String InternationalCR = data.get("InternationalCR");
		String DomesticCR = data.get("DomesticCR");
		String PaymentOfConvenienceFee = data.get("PaymentOfConvenienceFee");
		
		Actions  action=new Actions(driver);
		
		action.moveToElement(driver.findElement(By.id("Leads_editView_fieldName_tpc_value"))).doubleClick().perform();
		scrollDown();
		moveToElement(MMS_HomePage.convfeeHeader);
		
		Reporter.reportStep("Convenience Fee Details");	
		//DR more than 2000

		   if (DRmorethan2k.length()>0){
		          waitForElementPresent(MMS_HomePage.DRmorethan2k,"DRmorethan2k Present");
		          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
		          type(MMS_HomePage.DRmorethan2k, DRmorethan2k, "JoiningFee");
		        
		   }
		 
		 //DR less 2k  
		 if (DRmorethan2k.length()>0){
	          waitForElementPresent(MMS_HomePage.DRlessthan2k,"DRlessthan2k Present");
	          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
	          type(MMS_HomePage.DRlessthan2k, DRmorethan2k, "JoiningFee");
	        
	   }
		 
		//international cr
		 if (InternationalCR.length()>0){
	          waitForElementPresent(MMS_HomePage.InternationalCR,"JoiningFee Present");
	          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
	          type(MMS_HomePage.InternationalCR, InternationalCR, "JoiningFee");
	        
	   }
		//DomesticCR
		 if (DomesticCR.length()>0){
	          waitForElementPresent(MMS_HomePage.DomesticCR,"JoiningFee Present");
	          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
	          type(MMS_HomePage.DomesticCR, DomesticCR, "JoiningFee");
	        
	   }
		 
		//PaymentOfConvenienceFee
		   if(PaymentOfConvenienceFee.length()>0){
				  waitForElementPresent(MMS_HomePage.PaymentOfConvenienceFee,"PaymentOfConvenienceFee Present");
				  click(MMS_HomePage.PaymentOfConvenienceFee,"PaymentOfConvenienceFee field clicked");
				  Thread.sleep(2000);
				
				  List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
			  
				  ArrayList<String> arr9 = new ArrayList<String>();
				  
				 
				  for(WebElement e: dropdown) {
				  String a = e.getText();
				      if(a.contains(PaymentOfConvenienceFee)) {
				    	  e.click();
				    	  Reporter.reportStep("PaymentOfConvenienceFee selected as :"+PaymentOfConvenienceFee);
				    	  break;
				      }
				  }
				  
				  
				  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
				 
			  }
		  
	}
	// domestic debit card details
	public static void fillDomesticDebitCardDetails(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
		String Leads_editView_fieldName_pos_online_non_qr_txn_onus = data.get("Leads_editView_fieldName_pos_online_non_qr_txn_onus");
		String Leads_editView_fieldName_pos_online_non_qr_txn_offus = data.get("Leads_editView_fieldName_pos_online_non_qr_txn_offus"); 
		String Leads_editView_fieldName_qr_code_txn_onus = data.get("Leads_editView_fieldName_qr_code_txn_onus");
		String Leads_editView_fieldName_qr_code_txn_offus = data.get("Leads_editView_fieldName_qr_code_txn_offus");

		Reporter.reportStep("Domestic Debit Card");
		Actions  action=new Actions(driver);
		
		String posnonqrlessthan2k = null,posnonqrgreaterthan2k;
		String posqrlessthan2k,posqrgreaterthan2k;
		
		
		action.moveToElement(driver.findElement(By.id("Leads_editView_fieldName_international_cr"))).doubleClick().perform();
		scrollDown();
		
		//Leads_editView_fieldName_pos_online_non_qr_txn_onus
		if (Leads_editView_fieldName_pos_online_non_qr_txn_onus.length()>0){
	          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_pos_online_non_qr_txn_onus,"Leads_editView_fieldName_pos_online_non_qr_txn_onus Present");
	          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
	          posnonqrlessthan2k=driver.findElement(MMS_HomePage.Leads_editView_fieldName_pos_online_non_qr_txn_onus).getAttribute("value");
	          type(MMS_HomePage.Leads_editView_fieldName_pos_online_non_qr_txn_onus, Leads_editView_fieldName_pos_online_non_qr_txn_onus, "Leads_editView_fieldName_pos_online_non_qr_txn_onus");
	        
	   }
	
		//Leads_editView_fieldName_pos_online_non_qr_txn_offus
				if (Leads_editView_fieldName_pos_online_non_qr_txn_offus.length()>0){
			          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_pos_online_non_qr_txn_offus,"Leads_editView_fieldName_pos_online_non_qr_txn_offus Present");
			          posnonqrgreaterthan2k=driver.findElement(MMS_HomePage.Leads_editView_fieldName_pos_online_non_qr_txn_offus).getAttribute("value");
			          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
			          type(MMS_HomePage.Leads_editView_fieldName_pos_online_non_qr_txn_offus, Leads_editView_fieldName_pos_online_non_qr_txn_offus, "Leads_editView_fieldName_pos_online_non_qr_txn_offus");
			        
			   }
		
				//Leads_editView_fieldName_qr_code_txn_onus
				if (Leads_editView_fieldName_qr_code_txn_onus.length()>0){
			          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_qr_code_txn_onus,"Leads_editView_fieldName_qr_code_txn_onus Present");
			          posqrlessthan2k=driver.findElement(MMS_HomePage.Leads_editView_fieldName_qr_code_txn_onus).getAttribute("value");
			          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
			          type(MMS_HomePage.Leads_editView_fieldName_qr_code_txn_onus, Leads_editView_fieldName_qr_code_txn_onus, "Leads_editView_fieldName_qr_code_txn_onus");
			        
			   }
		
				//Leads_editView_fieldName_qr_code_txn_offus
				if (Leads_editView_fieldName_qr_code_txn_offus.length()>0){
			          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_qr_code_txn_offus,"Leads_editView_fieldName_qr_code_txn_offus Present");
			          posqrgreaterthan2k=driver.findElement(MMS_HomePage.Leads_editView_fieldName_qr_code_txn_offus).getAttribute("value");
			          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
			          type(MMS_HomePage.Leads_editView_fieldName_qr_code_txn_offus, Leads_editView_fieldName_qr_code_txn_offus, "Leads_editView_fieldName_qr_code_txn_offus");
			        
			   }
				
				Reporter.reportStep("Business type value is :"+data.get("BusinessType"));
				
				Reporter.reportStep("Default value of POS online NONQR Txn lessthan 2000 is : "+posnonqrlessthan2k);
				
				Reporter.reportStep("POS transaction for domestic debit card kept separate ");
				
				Reporter.reportStep("POS and Non QR transaction for domestic debit card kept separate ");
				Reporter.SuccessReport("POS and Non QR transaction", "POS and Non QR transaction for Domestic debit card pass.");
	}

	public static void fillUPIDefaultDetails(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
		Reporter.reportStep("UPI");
		String Leads_editView_fieldName_less_than_2k = data.get("Leads_editView_fieldName_less_than_2k");
		String Leads_editView_fieldName_greater_than_2k = data.get("Leads_editView_fieldName_greater_than_2k"); 
		
		Actions  action=new Actions(driver);
		
		action.moveToElement(driver.findElement(By.id("Leads_editView_fieldName_international_cr"))).doubleClick().perform();
		scrollDown();
		
		//Leads_editView_fieldName_less_than_2k
		if (Leads_editView_fieldName_less_than_2k.length()>0){
	          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_less_than_2k,"Leads_editView_fieldName_less_than_2k Present");
	          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
	          type(MMS_HomePage.Leads_editView_fieldName_less_than_2k, Leads_editView_fieldName_less_than_2k, "Leads_editView_fieldName_less_than_2k");
	        
	   }
	
		//Leads_editView_fieldName_greater_than_2k
				if (Leads_editView_fieldName_greater_than_2k.length()>0){
			          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_greater_than_2k,"Leads_editView_fieldName_greater_than_2k Present");
			          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
			          type(MMS_HomePage.Leads_editView_fieldName_greater_than_2k, Leads_editView_fieldName_greater_than_2k, "Leads_editView_fieldName_greater_than_2k");
			        
			   }
			
	}

	// credit card details
		public static void fillCreditCardCategoryDetails(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
			// TODO Auto-generated method stub
			Reporter.reportStep("Credit card Category");
			String Leads_editView_fieldName_standard_onus = data.get("Leads_editView_fieldName_standard_onus");
			String Leads_editView_fieldName_standard_domestic_offus = data.get("Leads_editView_fieldName_standard_domestic_offus"); 
			String Leads_editView_fieldName_standard_international_offus = data.get("Leads_editView_fieldName_standard_international_offus");
			String Leads_editView_fieldName_premium_onus = data.get("Leads_editView_fieldName_premium_onus");
			String Leads_editView_fieldName_premium_domestic_offus = data.get("Leads_editView_fieldName_premium_domestic_offus");
			String Leads_editView_fieldName_premium_international_offus = data.get("Leads_editView_fieldName_premium_international_offus");
			String Leads_editView_fieldName_super_premium_onus = data.get("Leads_editView_fieldName_super_premium_onus");
			String Leads_editView_fieldName_super_premium_domestic_offus = data.get("Leads_editView_fieldName_super_premium_domestic_offus");
			String Leads_editView_fieldName_superpremium_int_offus = data.get("Leads_editView_fieldName_superpremium_int_offus");
			
			Actions  action=new Actions(driver);
			
			action.moveToElement(driver.findElement(By.id("Leads_editView_fieldName_international_cr"))).doubleClick().perform();
			scrollDown();
			
			//Leads_editView_fieldName_standard_onus
			if (Leads_editView_fieldName_standard_onus.length()>0){
		          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_standard_onus,"Leads_editView_fieldName_standard_onus Present");
		          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
		          type(MMS_HomePage.Leads_editView_fieldName_standard_onus, Leads_editView_fieldName_standard_onus, "Leads_editView_fieldName_standard_onus");
		        
		   }
		
			//Leads_editView_fieldName_standard_domestic_offus
					if (Leads_editView_fieldName_standard_domestic_offus.length()>0){
				          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_standard_domestic_offus,"Leads_editView_fieldName_standard_domestic_offus Present");
				          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
				          type(MMS_HomePage.Leads_editView_fieldName_standard_domestic_offus, Leads_editView_fieldName_standard_onus, "Leads_editView_fieldName_standard_domestic_offus");
				        
				   }
			
					//Leads_editView_fieldName_standard_domestic_offus
					if (Leads_editView_fieldName_standard_international_offus.length()>0){
				          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_standard_international_offus,"Leads_editView_fieldName_standard_international_offus Present");
				          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
				          type(MMS_HomePage.Leads_editView_fieldName_standard_international_offus, Leads_editView_fieldName_standard_international_offus, "Leads_editView_fieldName_standard_domestic_offus");
				        
				   }
			
					//Leads_editView_fieldName_premium_onus
					if (Leads_editView_fieldName_premium_onus.length()>0){
				          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_premium_onus,"Leads_editView_fieldName_premium_onus Present");
				          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
				          type(MMS_HomePage.Leads_editView_fieldName_premium_onus, Leads_editView_fieldName_standard_international_offus, "Leads_editView_fieldName_premium_onus");
				        
				   }
					
					//Leads_editView_fieldName_premium_domestic_offus
					if (Leads_editView_fieldName_premium_domestic_offus.length()>0){
				          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_premium_domestic_offus,"Leads_editView_fieldName_premium_domestic_offus Present");
				          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
				          type(MMS_HomePage.Leads_editView_fieldName_premium_domestic_offus, Leads_editView_fieldName_premium_domestic_offus, "Leads_editView_fieldName_premium_domestic_offus");
				        
				   }
					
					//Leads_editView_fieldName_premium_international_offus
					if (Leads_editView_fieldName_premium_international_offus.length()>0){
				          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_premium_international_offus,"Leads_editView_fieldName_premium_international_offus Present");
				          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
				          type(MMS_HomePage.Leads_editView_fieldName_premium_international_offus, Leads_editView_fieldName_premium_international_offus, "Leads_editView_fieldName_premium_international_offus");
				        
				   }
					
					//Leads_editView_fieldName_premium_international_offus
					if (Leads_editView_fieldName_super_premium_onus.length()>0){
				          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_super_premium_onus,"Leads_editView_fieldName_super_premium_onus Present");
				          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
				          type(MMS_HomePage.Leads_editView_fieldName_super_premium_onus, Leads_editView_fieldName_super_premium_onus, "Leads_editView_fieldName_super_premium_onus");
				        
				   }
					
					//Leads_editView_fieldName_super_premium_domestic_offus
					if (Leads_editView_fieldName_super_premium_domestic_offus.length()>0){
				          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_super_premium_domestic_offus,"Leads_editView_fieldName_super_premium_domestic_offus Present");
				          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
				          type(MMS_HomePage.Leads_editView_fieldName_super_premium_domestic_offus, Leads_editView_fieldName_super_premium_domestic_offus, "Leads_editView_fieldName_super_premium_domestic_offus");
				        
				   }
					
					//Leads_editView_fieldName_superpremium_int_offus
					if (Leads_editView_fieldName_superpremium_int_offus.length()>0){
				          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_superpremium_int_offus,"Leads_editView_fieldName_superpremium_int_offus Present");
				          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
				          type(MMS_HomePage.Leads_editView_fieldName_superpremium_int_offus, Leads_editView_fieldName_superpremium_int_offus, "Leads_editView_fieldName_superpremium_int_offus");
				        
				   }
				
		}


	public static void fillFeeProgramDetails(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
		String JoiningFee = data.get("JoiningFee");
		String AnnualSetupFee = data.get("AnnualSetupFee"); 
		String ConvenienceFeeType = data.get("ConvenienceFeeType");
		String TPCType = data.get("TPCType");
		String TPCValue = data.get("TPCValue");
		
		Reporter.reportStep("Fee Program");	
		Actions  action=new Actions(driver);
		
		action.moveToElement(driver.findElement(By.id("Leads_editView_fieldName_joining_fee"))).doubleClick().perform();
		scrollDown();
		
		//JoiningFee

		   if (JoiningFee.length()>0){
		          waitForElementPresent(MMS_HomePage.JoiningFee,"JoiningFee Present");
		          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
		          type(MMS_HomePage.JoiningFee, JoiningFee, "JoiningFee");
		        
		   }
		
		//AnnualSetupFee
		   if (AnnualSetupFee.length()>0){
		          waitForElementPresent(MMS_HomePage.AnnualSetupFee,"AnnualSetupFee Present");
		          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
		          type(MMS_HomePage.AnnualSetupFee, AnnualSetupFee, "AnnualSetupFee");
		        
		   }
		   
		//ConvenienceFeeType
		   if(ConvenienceFeeType.length()>0){
				  waitForElementPresent(MMS_HomePage.ConvenienceFeeType,"ConvenienceFeeType Present");
				  click(MMS_HomePage.ConvenienceFeeType,"ConvenienceFeeType field clicked");
				  Thread.sleep(2000);
				 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
				 
				  List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
			  
				  ArrayList<String> arr9 = new ArrayList<String>();
				 
				  for(WebElement e: dropdown) {
					  String a = e.getText();
					  arr9.add(a);
				  }
				  
				  
				  
				  
				  for(WebElement e: dropdown) {
				  String a = e.getText();
				      if(a.contains(ConvenienceFeeType)) {
				    	  e.click();
				    	  Reporter.reportStep("ConvenienceFeeType selected as :"+ConvenienceFeeType);
				    	  break;
				      }
				  }
				  
				  if(arr9.contains("No") && arr9.contains("Flat") && arr9.contains("Percentage")) {
						
	                     
						
	                     Reporter.reportStep("Convience fee option contains Flat and Percentage options.");
		
	                     Reporter.reportStep("TC 107 Pass.");
		
	                     Reporter.SuccessReport("Convience fee Type", "Convience fee Type validations pass.");
		
	              }else {
		
	                     Reporter.failureReport("Convience fee Type", "Convience fee Type validations failed.");
		
	                     Reporter.reportStep("TC 107 Fail.");
		
	              }
		
	 
		
	                 Reporter.reportStep("Convenience Fee Option");
		
	                 Reporter.reportStep("TC 106 Pass.");
		
	                 Reporter.SuccessReport("Convenience Fee validations", "Convenience Fee validations Pass");
		
	                 System.out.println("Lead Page is having Convenience Fee option"); 
				
				  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
				
			  }
		   
		   //TPCType
		   if(TPCType.length()>0){
				  waitForElementPresent(MMS_HomePage.TPCType,"TPCType Present");
				  click(MMS_HomePage.TPCType,"TPCType field clicked");
				  Thread.sleep(2000);
				
				  List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
			  

				  ArrayList<String> arr10 = new ArrayList<String>();
	
                 
	
				  	for(WebElement e: dropdown) {
	
                             String a = e.getText();
	
                             arr10.add(a);
	
	
                        } 
				  
				  
				  
				  
				  
				  for(WebElement e: dropdown) {
				  String a = e.getText();
				      if(a.contains(TPCType)) {
				    	  e.click();
				    	  Reporter.reportStep("TPCType selected as :"+TPCType);
				    	  break;
				      }
				  }
				  
				  

				  if(arr10.contains("No") && arr10.contains("Flat") && arr10.contains("Percentage")) {
					  
                     Reporter.reportStep("TPC Type option contains Flat and Percentage options.");
	
                     Reporter.reportStep("TC 109 Pass.");
	
                     Reporter.SuccessReport("TPC Type", "TPC Type validations pass.");
	
				  		}else {
	
                     Reporter.failureReport("TPC Type", "TPC Type validations failed.");
	
                     Reporter.reportStep("TC 109 Fail.");
	
				  		}
					
				  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
				
			  }
		 
		 //AnnualSetupFee
		   if (TPCValue.length()>0){
		          waitForElementPresent(MMS_HomePage.TPCValue,"AnnualSetupFee Present");
		          type(MMS_HomePage.TPCValue, TPCValue, "AnnualSetupFee");
		          
		          Reporter.reportStep("TPC value selection Option");

	              Reporter.reportStep("TC 108 Pass.");
		
	              Reporter.SuccessReport("TPC value selection validations", "TPC value selection validations Pass");
		
	              System.out.println("Lead Page is having TPC value selection option");
		         }
		
	}


	public static void fillPaymentDetails(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
		
		String PaymentType = data.get("PaymentType");
		String AccountNumber = data.get("AccountNumber"); 
		String AccountName = data.get("AccountName");
		String PaymentCalculation = data.get("PaymentCalculation");
		String SettelementCurrency = data.get("SettelementCurrency");
		String StatementAdviceFormat = data.get("StatementAdviceFormat");
		
		Reporter.reportStep("Payment details");	
		Actions  action=new Actions(driver);
		action.moveToElement(driver.findElement(By.id("Leads_editView_fieldName_account_number"))).doubleClick().perform();
		
		driver.findElement(By.xpath("//*[@id='EditView']/div[4]/div/div/div[5]/h4")).click();
		
		 scrollDown();
		
		 if(PaymentType.length()>0){
			  waitForElementPresent(MMS_HomePage.PaymentType,"PaymentType field Present");
			  click(MMS_HomePage.PaymentType,"PaymentType clicked.");
			  
			  Thread.sleep(2000);
				 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
				  List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
			  
				  ArrayList<String> arr = new ArrayList<String>();
				  
				  for(WebElement e: dropdown) {
						String a = e.getText();
						arr.add(a);
											  
					}
											  
				  
				  for(WebElement e: dropdown) {
				  String a = e.getText();
				      if(a.contains(PaymentType)) {
				    	  e.click();
				    	  Reporter.reportStep("PaymentType selected as :"+PaymentType);
				    	  break;
				      }
				  }
				 
				  if(arr.contains("NEFT") && arr.contains("A/C Credit")) {
					  
					  Reporter.reportStep("FIRC dropdown contains NEFT and A/C Credit options.");
					  Reporter.reportStep("TC 22,101 Pass.");
					  Reporter.SuccessReport("Payment Type", "Payment Type validations pass.");
				  }else {
					  Reporter.failureReport("Payment Type", "Payment Type validations failed.");
					  Reporter.reportStep("TC 22,101 Fail.");
				  }
					
				  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
			  
		  }
		 
		 //Account number
	
		   if (AccountNumber.length()>0){
		          waitForElementPresent(MMS_HomePage.AccountNumber,"AccountNumber Present");
		          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
		          type(MMS_HomePage.AccountNumber, AccountNumber, "Mailing Address Line 1");
		        
		   }
		   
		
		   
		 //Account name
			
		   if (AccountName.length()>0){
		          waitForElementPresent(MMS_HomePage.AccountName,"AccountName Present");
		          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
		          type(MMS_HomePage.AccountName, AccountName, "AccountName");
		        
		   }
		   
		   //payment calculation
		
			  if(PaymentCalculation.length()>0){
				  waitForElementPresent(MMS_HomePage.PaymentCalculation,"PaymentCalculationfield Present");
				  click(MMS_HomePage.PaymentCalculation,"PaymentCalculation field Present");
				  Thread.sleep(2000);
				 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
				 
				  List<WebElement> dropdown1= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
			  
				  for(WebElement e: dropdown1) {
				  String a = e.getText();
				      if(a.contains(PaymentCalculation)) {
				    	  e.click();
				    	  Reporter.reportStep("PaymentCalculation selected as :"+PaymentCalculation);
				    	  break;
				      }
				  }
					
				  
					
				  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
				 // driver.findElement(By.id("customer_display")).click();
				
				  
			  }
			  
			  //Settelemnt currency
			  if(SettelementCurrency.length()>0){
				  waitForElementPresent(MMS_HomePage.SettelementCurrency,"SettelementCurrency field Present");
				  click(MMS_HomePage.SettelementCurrency,"SettelementCurrency field Present");
				  Thread.sleep(2000);
				 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
				 
				  List<WebElement> dropdown2= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
				  
				  ArrayList<String> arr = new ArrayList<String>();
				  
				  for(WebElement e: dropdown2) {
					  String a = e.getText();
					  arr.add(a);
					  
					  }
				  
				  for(WebElement e: dropdown2) {
				  	String a = e.getText();
				      if(a.contains(SettelementCurrency)) {
				    	  e.click();
				    	  Reporter.reportStep("SettelementCurrency selected as :"+SettelementCurrency);
				    	  break;
				      }
				  }
				  
				  if(arr.contains("INR") && arr.contains("USD")) {
					  Reporter.SuccessReport("SettelementCurrency", "SettelementCurrency validations pass.");
					  Reporter.reportStep("SettelementCurrency contains INR and USD options.");
					  Reporter.reportStep("TC 22, 32 Pass.");
					  Reporter.reportStep("TC 06 & TC 32 Pass.");
				  }else {
					  Reporter.failureReport("FIRC Frequency", "FIRC Frequency validations failed.");
					  Reporter.reportStep("TC 22 Fail.");
					  Reporter.reportStep("TC 06 & TC 32 Fail.");
				  }
				
				  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
				 
			  }
			  
			  //Staement advice format
			
			  if(StatementAdviceFormat.length()>0){
				  waitForElementPresent(MMS_HomePage.StatementAdviceFormat,"Merchant DBA field Present");
				  click(MMS_HomePage.StatementAdviceFormat,"Merchant DBA field Present");
				  Thread.sleep(2000);
				 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
				 
				  List<WebElement> dropdown3= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
			  
				  ArrayList<String> arr = new ArrayList<String>();
				  
				  for(WebElement e: dropdown3) {
						String a = e.getText();
						arr.add(a);
											  
					}
				  
				  
				  for(WebElement e: dropdown3) {
				  String a = e.getText();
				      if(a.contains(StatementAdviceFormat)) {
				    	  e.click();
				    	  Reporter.reportStep("Statement Advice Format selected as :"+StatementAdviceFormat);
				    	  break;
				      }
				  }
				  
				  
				  if(arr.contains("PDF") && arr.contains("EXCEL")) {
					  
					  Reporter.reportStep("Statement Advice Format dropdown contains EXCEL and PDF options.");
					  Reporter.reportStep("TC 27,103,104 Pass.");
					  Reporter.SuccessReport("Statement Advice Format", "Statement Advice Format pass.");
				  }else {
					  Reporter.failureReport("Statement Advice Format", "Statement Advice Format validations failed.");
					  Reporter.reportStep("TC 27,103,104 Fail.");
				  }
					
				  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
			
			  }
		
	}


	public static void fillMerchantAddressDetails(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
		
		String MerchantAddressLine1 = data.get("MerchantAddressLine1");
        String MerchantAddressLine2 = data.get("MerchantAddressLine2");
        //String MerchantPinCode = data.get("MerchantPinCode");
        String MerchantPinCode1 = data.get("MerchantPinCode1");
        String PrimaryEmail = data.get("PrimaryEmail");
        String SecondaryEmail = data.get("SecondaryEmail");
        String MerchantPanNumber = data.get("MerchantPanNumber");
        String PrimaryContactPerson = data.get("PrimaryContactPerson");
        String SecondaryMobileNumber = data.get("SecondaryMobileNumber");
        String PrimaryMobileNumber = data.get("PrimaryMobileNumber");
        String Landline = data.get("Landline");
        String MerchantCity = data.get("MerchantCity");
		
        Actions  action=new Actions(driver);
		
		action.moveToElement(driver.findElement(By.id("Leads_editView_fieldName_mail_address_line_1"))).doubleClick().perform();
		//scrollDown();
	
		Reporter.reportStep("Merchant Address Details");
		//Merchant Address Details
		
		// copy Mailing adress feature
		scrollDown();
		Thread.sleep(1000);
		waitForElementPresent(MMS_HomePage.MailingAddressDetailsection,"Mailing Address Line1 field Present");
		click(MMS_HomePage.MailingAddressDetailsection,"Mailing Address Detailsection clicked successfully");
		//moveToElement(MMS_HomePage.MailingAddressLine1);
		scrollDown();
		 waitForElementPresent(MMS_HomePage.MailingAddressLine1,"Mailing Address Line1 field Present");
		 type(MMS_HomePage.MailingAddressLine1, "Test copy mailing address1", "MailingAddressLine1");
		
		 waitForElementPresent(MMS_HomePage.MailingAddressLine2,"Mailing Address Line2 field Present");
		 type(MMS_HomePage.MailingAddressLine2, "Test copy mailing address2", "MailingAddressLine2");
		 
		 Reporter.SuccessReport("Merchant mailing address", "Merchant mailing address present.");
		 
		 moveToElement(MMS_HomePage.MerchantAddressLine1);
		 Reporter.reportStep("Navigated to Merchant Address section.");
		 scrollUp();
		// Robot robot = new Robot();
		// robot.keyPress(KeyEvent.VK_PAGE_UP);
		 
		 action.moveToElement(driver.findElement(By.id("Leads_editView_fieldName_merchant_address_line_1"))).doubleClick().perform();
		 waitForElementPresent(MMS_HomePage.CopyMailingAddress," Copy Mailing Address");
		 click(MMS_HomePage.CopyMailingAddress,"Copy Mailing Address clicked successfully");
		 
		 String add1= driver.findElement(MMS_HomePage.MerchantAddressLine1).getAttribute("value");
		 String add2= driver.findElement(MMS_HomePage.MerchantAddressLine2).getAttribute("value");
		 
		 Reporter.reportStep("Merchant address line1 value visible is :"+add1);
		 Reporter.reportStep("Merchant address line2 value visible is :"+add2);
		 
		 
		 if(add1.equals("Test copy mailing address1")&& add2.equals("Test copy mailing address2")) {
			 Reporter.SuccessReport("Copy mailing address", "Copy mailing address working correctly.");
			 Reporter.reportStep("TC15 Pass");
		 }else {
			 Reporter.failureReport("Copy mailing address", "Copy mailing address not working correctly.");
			 Reporter.reportStep("TC15 Fail");
		 }
		 
		
          Thread.sleep(1000);
          scrollUp();
          Thread.sleep(1000);
       
          Thread.sleep(1000);
          action.moveToElement(driver.findElement(By.xpath("//*[@id='EditView']/div[4]/div/div/div[3]/h4"))).doubleClick().perform();
          //MerchantAddressLine1
            if(MerchantAddressLine1.length()>0){      
                   waitForElementPresent(MMS_HomePage.MerchantAddressLine1,"Merchant Address Line1 field Present");
                   type(MMS_HomePage.MerchantAddressLine1, MerchantAddressLine1, "MerchantAddressLine1");
                 
            }
                 //MerchantAddressLine2
            if(MerchantAddressLine2.length()>0){
                   waitForElementPresent(MMS_HomePage.MerchantAddressLine2,"Merchant Address Line2 field Present");
                   type(MMS_HomePage.MerchantAddressLine2, MerchantAddressLine2, "MerchantAddressLine2");
                 
            }
          
               //CopyMailingAddress
          if (waitForElementPresent(MMS_HomePage.CopyMailingAddress,"Click on Copy Mailing Addresst"))
               {                          
                     click(MMS_HomePage.CopyMailingAddress," clicked successfully");
                     Reporter.reportStep("Copy Mailing Address Option - TC 98 Pass");
                     Reporter.SuccessReport("Copy Mailing Address validations", "Copy Mailing Address validations Pass");
                     Thread.sleep(2000);
                     waitForVisibilityOfElement(MMS_HomePage.CopyMailingAddress,"link Present");
                     click(MMS_HomePage.CopyMailingAddress," clicked successfully");
                     
               }
          
         
          scrollUp();
        
          if(MerchantPinCode1.length()>0){
          		waitForElementPresent(MMS_HomePage.MerchantPinCode,"Click on search in buttton");      
                   waitForElementPresent(MMS_HomePage.MerchantPinCode,"");                
                     click(MMS_HomePage.MerchantPinCode," clicked successfully");
                     Thread.sleep(2000);
                     waitForVisibilityOfElement(MMS_HomePage.MerchantPinCodetype,"found pin text box");
                     type(MMS_HomePage.MerchantPinCodetype, MerchantPinCode1, "MerchantPinCode1");
                     click(MMS_HomePage.SearchPin," Searched successfully");
                     Thread.sleep(2000);
                     click(MMS_HomePage.SelectSearchPin," Searched successfully");
                    
                     Reporter.SuccessReport("Search Pin fuctionality", "Search Pin fuctionality Present.");
                     Reporter.reportStep("Search Pin functionality present.");
                     Reporter.reportStep("TestCase passed:90,91,.");
               }
          
          
          Reporter.SuccessReport("Merchant Address Validations", "Merchant address validations passed.");
          Reporter.reportStep("TestCases covered are:87,88,89");
          
          if(PrimaryEmail.length()>0){
                 waitForElementPresent(MMS_HomePage.PrimaryEmail,"Primary Email field Present");
                 type(MMS_HomePage.PrimaryEmail, PrimaryEmail, "PrimaryEmail");
               
          }
          
          if(SecondaryEmail.length()>0){
                 waitForElementPresent(MMS_HomePage.SecondaryEmail,"Secondary Email field Present");
                 type(MMS_HomePage.SecondaryEmail, SecondaryEmail, "SecondaryEmail");
               
          }
          
          if(MerchantPanNumber.length()>0){
                 waitForElementPresent(MMS_HomePage.MerchantPanNumber,"Merchant PanNumber field Present");
                 type(MMS_HomePage.MerchantPanNumber, MerchantPanNumber, "MerchantPanNumber");
                 Reporter.reportStep("Merchant Pan Number field is editable.");
                 Reporter.SuccessReport("Merchant Pan Number", "Merchant Pan Number can be entered.");
                 Reporter.reportStep("Test Case 63 passed.");
          }
          
          if(PrimaryContactPerson.length()>0){
                 waitForElementPresent(MMS_HomePage.PrimaryContactPerson,"Primary Contact Person field Present");
                 type(MMS_HomePage.PrimaryContactPerson, PrimaryContactPerson, "PrimaryContactPerson");
               
          }
          
          if(SecondaryMobileNumber.length()>0){
                 waitForElementPresent(MMS_HomePage.SecondaryMobileNumber,"Secondary Mobile Number field Present");
                 type(MMS_HomePage.SecondaryMobileNumber, SecondaryMobileNumber, "SecondaryMobileNumber");
               
                 Reporter.reportStep("Secondary Mobile Number Option - TC 95 Pass");
             	
                 Reporter.SuccessReport("Secondary Mobile Number validations", "Secondary Mobile Number validations Pass");
	
                 System.out.println("Landline option is available to enter Secondary Mobile Number");
          }
          
          if(PrimaryMobileNumber.length()>0){
                 waitForElementPresent(MMS_HomePage.PrimaryMobileNumber,"Primary Mobile Number field Present");
                 type(MMS_HomePage.PrimaryMobileNumber, PrimaryMobileNumber, "PrimaryMobileNumber");
                 Reporter.SuccessReport("Mobile Number", "Mobile Number validation passed.");
                 Reporter.reportStep("Primary Mobile Number Option - TC 95 Pass");
                 Reporter.SuccessReport("Primary Mobile Number validations", "Primary Mobile Number validations Pass");
               
          }
          
          Reporter.SuccessReport("Mobile Number Validation", "Mobile number validation paas.");
          
          JavascriptExecutor js1 = (JavascriptExecutor) driver;
          js1.executeScript("window.scrollBy(0,100)");
          
          if(Landline.length()>0){
                 waitForElementPresent(MMS_HomePage.Landline,"Landline field Present");
                 type(MMS_HomePage.Landline, Landline, "Landline");
                 Reporter.reportStep("Landline Option - TC 94 Pass");
                 Reporter.SuccessReport("Landline validations", "Landline validations Pass");
               
          }
          
          if(MerchantCity.length()>0){
        	  		 waitForElementPresent(MMS_HomePage.MerchantCity,"Click on Search Merchant city`");      
        	  		 waitForElementPresent(MMS_HomePage.MerchantCity,"");                   
                     click(MMS_HomePage.MerchantCity," clicked successfully");
                     waitForPageLoaded();
                     waitForElementPresent(MMS_HomePage.MerchantCitytype,"found citytext box");
                     type(MMS_HomePage.MerchantCitytype, MerchantCity, "MerchantPinCode1");
                     click(MMS_HomePage.Searchcity," Searched successfully");
                     Thread.sleep(2000);
                     waitForElementPresent(MMS_HomePage.SelectSearchcity,"Landline field Present");
                     click(MMS_HomePage.SelectSearchcity,"selected Searched city successfully");
                     
                     Reporter.reportStep("MerchantCity Option - TC 96 Pass");
                     Reporter.SuccessReport("Merchant City validations", "Merchant City validations Pass");
                     System.out.println("MerchantCity option is having option for entering merchant city using search option");
                       
               }

		
	}
	
	//mailing address
	public static void fillMailingAddress(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
		
					String MailingAddressLine1 = data.get("MailingAddressLine1");
					String MailingAddressLine2 = data.get("MailingAddressLine2");
					String MailingPinCode1 = data.get("MailingPinCode1");
					String SezFlag = data.get("SezFlag");
					String ownerName = data.get("ownerName");
					String OwnerMobileNumber = data.get("OwnerMobileNumber");
					String CityName = data.get("CityName");
					
					 Actions  action=new Actions(driver);
						
					action.moveToElement(driver.findElement(By.id("Leads_editView_fieldName_mail_address_line_1"))).doubleClick().perform();
					
			Reporter.reportStep("Mailing address details");		
			
			// check copy functionality
		
		   //Mailing Address Line 1
		   if (MailingAddressLine1.length()>0){
		          waitForElementPresent(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
		          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
		          type(MMS_HomePage.MailingAddressLine1, MailingAddressLine1, "Mailing Address Line 1"); 
		          Reporter.reportStep("Mailing Address Line1 Option - TC 97 Pass");
		          Reporter.SuccessReport("Mailing Address Line1 validations", "Mailing Address Line1 City validations Pass");
		          System.out.println("Mailing Address Line1 option is having option for entering Mailing Address Line");
		   }
		   
		   //Mailing Address Line 2
		   if (MailingAddressLine2.length()>0){
		          waitForElementPresent(MMS_HomePage.MailingAddressLine2,"Mailing Address Line 2 Present");
		          type(MMS_HomePage.MailingAddressLine2, MailingAddressLine2, "Mailing Address Line 2");
		          
		          Reporter.reportStep("Mailing Address Line2 Option - TC 97 Pass");
		          Reporter.SuccessReport("Mailing Address Line2 validations", "Mailing Address Line2 City validations Pass");
		          System.out.println("Mailing Address Line2 option is having option for entering Mailing Address Line");
		        } 
		   
		   
		  if (waitForElementPresent(MMS_HomePage.CopyMerchantAddress,"Copy Merchant Address Link Present")){
		          click(MMS_HomePage.CopyMerchantAddress,"Copy Merchant Address");
		        }
		
		 
		  
		  String add1= driver.findElement(MMS_HomePage.MailingAddressLine1).getAttribute("value");
		  String add2= driver.findElement(MMS_HomePage.MailingAddressLine2).getAttribute("value");
			 
		  // copy merchant adress line code
		  Reporter.reportStep("Value in MailingAddressLine1 is: "+ add1);
		  Reporter.reportStep("Value in MailingAddressLine1 is: "+ add2);
			 
			 if(add1.equals("Test copy mailing address1")&& add2.equals("Test copy mailing address2")) {
				 Reporter.SuccessReport("Copy merchant address", "Copy merchant address working correctly.");
				 Reporter.reportStep("TC16 Pass");
			 }else {
				 Reporter.failureReport("Copy merchant address", "Copy merchant address not working correctly.");
				 Reporter.reportStep("TC16 Fail");
			 }
		  
		  
		  scrollDown();
		   	//Mailing Pin Code
		   	if (MailingPinCode1.length()>0) {
			   waitForElementPresent(MMS_HomePage.MailingPinCode,"Mailing Pin Code Present");
		            click(MMS_HomePage.MailingPinCode,"Mailing Pin Code search Button clicked successfully");
		            Thread.sleep(2000);
		            waitForElementPresent(MMS_HomePage.MailingPinCode1,"Mailing Pin Code 1 Present");
		            type(MMS_HomePage.MailingPinCode1,MailingPinCode1,"Mailing Pin Code 1 entered successfully");
		            Thread.sleep(2000);
		            waitForElementPresent(MMS_HomePage.ClickSearch,"Click Search result Present");
		            click(MMS_HomePage.ClickSearch,"Search button clicked successfully");
		            Thread.sleep(2000);
					waitForElementPresent(MMS_HomePage.ClickResult,"Mailing PIN code search result field Present");
					click(MMS_HomePage.ClickResult,"result field clicked.");
		              
		        }
		
		 //SezFlag
		   if(SezFlag.length()>0){
			   moveToElement(MMS_HomePage.SezFlag);
			   scrollDown();
			   //scrollDown();
		       waitForElementPresent(MMS_HomePage.SezFlag,"Sez Flag field Present");
		                               
		          click(MMS_HomePage.SezFlag,"Sez Flag field clicked.");
		          
		          Thread.sleep(2000);
		              // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
		           List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
		          
		                for(WebElement e: dropdown) {
		                String a = e.getText();
		                    if(a.contains(SezFlag)) {
		                       e.click();
		                      Reporter.reportStep("SezFlag selected as :"+SezFlag);
		                       break;
		                    }
		                }
		                 
		                action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
 
		   			}
		
		   
		 //owner Name
		   if (ownerName.length()>0){
		          waitForElementPresent(MMS_HomePage.ownerName,"owner Name Present");
		          type(MMS_HomePage.ownerName, ownerName, "owner Name");
		          Reporter.reportStep("owner Name Option - TC 99 Pass");
		          Reporter.SuccessReport("owner Name validations", "owner Name validations Pass");
		          System.out.println("owner Name option is having option to add owners name");
		        } 
		   
		 //Owner Mobile Number
		   if (OwnerMobileNumber.length()>0){
		          waitForElementPresent(MMS_HomePage.OwnerMobileNumber,"Owner Mobile Number Present");
		          type(MMS_HomePage.OwnerMobileNumber, OwnerMobileNumber, "Owner Mobile Number");
		          
		        } 
		   
		   //Mail City
		   if (CityName.length()>0) {
			   waitForElementPresent(MMS_HomePage.MailCity,"Mail City Present");
		              click(MMS_HomePage.MailCity,"Mail City search Button clicked successfully");
		              Thread.sleep(2000);
		              waitForElementPresent(MMS_HomePage.CityName,"City Name Present");
		              type(MMS_HomePage.CityName,CityName,"City Name entered successfully");
		              click(MMS_HomePage.ClickSearch1,"Search button clicked successfully");
		              Thread.sleep(2000);
		              waitForElementPresent(MMS_HomePage.ClickResult1,"Clicked Result1 Present");
		              click(MMS_HomePage.ClickResult1,"Searched Result clicked successfully");
		              
		              Reporter.reportStep("Mail City Option - TC 100 Pass");
		              Reporter.SuccessReport("Mail City validations", "Mail City validations Pass");
		              System.out.println("Mail City option is having option to add merchant mailing city");
		        }
		   
	}


	public static void fillMerchantDetails(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
				Reporter.reportStep("Merchant Details");
		// data from excel sheet
				String ApplicationSource = data.get("ApplicationSource");
				String ApplicationNumber = data.get("ApplicationNumber");
				String MerchantDBAName = data.get("MerchantDBAName");
				String GroupMerchant = data.get("GroupMerchant");
				String ParentMerchant = data.get("ParentMerchant");
				String MerchantLegalName = data.get("MerchantLegalName");
				String MerchantIdentification = data.get("MerchantIdentification");
				String MerchantIdentificationOldNo = data.get("MerchantIdentificationOldNo");
				String MerchantClassification = data.get("MerchantClassification");
				String PreferredLanguage = data.get("PreferredLanguage");
				String CardAcceptance = data.get("CardAcceptance");
				String AggrementDate = data.get("AggrementDate"); 
				String MerchantStatus = data.get("MerchantStatus"); 
				String NewtotheWorld = data.get("NewtotheWorld");  
				String FirmPanNumber = data.get("FirmPanNumber"); 
				String RMName = data.get("RMName"); 
				String RMCode = data.get("RMCode"); 
				String MESegment = data.get("MESegment"); 
				String BusinessEntity = data.get("BusinessEntity"); 
				String MonthlyLimit = data.get("MonthlyLimit");  
				String RiskApprovalWaiver = data.get("RiskApprovalWaiver");
				String MCC = data.get("MCC"); 
				String SchemeBacklistCheck = data.get("SchemeBacklistCheck"); 
				String DailyLimit = data.get("DailyLimit");
				String PertxnLimit = data.get("PerTransactionLimit"); 
				String FIRCFrequency = data.get("FIRCFrequency"); 
				String BranchCode = data.get("BranchCode"); 
				String AverageMonthlyBalance = data.get("AverageMonthlyBalance");
				String EcommerceIndicator = data.get("EcommerceIndicator"); 
				String PromoCode = data.get("PromoCode");
//				
//				
//		
				waitForPageLoaded();
				
				//Application source
				/*
				if (waitForElementPresent(MMS_HomePage.AppnSource_drp,"Application source dropdown Present"))
				{
					
					selectByVisibleText(MMS_HomePage.AppnSource_drp, ApplicationSource, "application source");
				}
				//rohan code
				*/
//				// customer name
//				waitForPageLoaded();
//				if (waitForElementPresent(MMS_HomePage.Customer,"Application source dropdown Present"))
//				{
//					 String b= driver.findElement(MMS_HomePage.Customer).getAttribute("value");
//					 if(b.contains("YES BANK")) {
//						 Reporter.reportStep("Customer name visible on the UI is :"+b);
//						 Reporter.reportStep("TestCase 40,41 Passed.");
//						 Reporter.SuccessReport("Customer name validations", "Customer name validations pass.");
//					 }
//					
//				}
				
				if(ApplicationSource.length()>0){
					
				  waitForElementPresent(MMS_HomePage.AppnSource_drp,"Application source dropdown Present");
				  Reporter.reportStep("Application source dropdown Present");
				  click(MMS_HomePage.AppnSource_drp,"Application Source field Present");
				//String add1= driver.findElement(MMS_HomePage.AppnSource_drp).getAttribute("value");

					
				  List<WebElement> AppnSource_drpdropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));

				
				  	for(WebElement e: AppnSource_drpdropdown) {
					
			          String a = e.getText();
				
			              if(a.contains(ApplicationSource)) {
				
			                    e.click();	
			                    Reporter.SuccessReport("ApplicationSource" +ApplicationSource, "Application source option is selected from dropdown");
				
			                    System.out.println("Application source " +ApplicationSource+ " option is selected from dropdown");
				
			                    break;
				
			                    }

				  	}
				
				waitForPageLoaded();
				Thread.sleep(2000);
			
					 String b= driver.findElement(MMS_HomePage.Customer).getAttribute("value");
					 if(b.contains("YES BANK")) {
						 Reporter.reportStep("Customer name visible on the UI is :"+b);
						 Reporter.reportStep("TestCase 40,41 Passed.");
						 Reporter.SuccessReport("Customer name validations", "Customer name validations pass.");
					 }
					
				
				
				
				//Application number
				  if(ApplicationNumber.length()>0){
					  waitForElementPresent(MMS_HomePage.AppnNumber_txt,"Application number field Present");
					  type(MMS_HomePage.AppnNumber_txt, ApplicationNumber, "Application number");
					  Reporter.reportStep("TestCase 38 Passed.");
					  Reporter.SuccessReport("Application number", "Application number field accepts  numeric value.");
					  
				  }
				  
				  //Merchant DBA Name
				  if(MerchantDBAName.length()>0){
					  waitForElementPresent(MMS_HomePage.MerchantDBAname_txt,"Merchant DBA field Present");
					  type(MMS_HomePage.MerchantDBAname_txt, MerchantDBAName, "Merchant DBA Name");
					  
					  String maxlength= driver.findElement(MMS_HomePage.MerchantDBAname_txt).getAttribute("maxlength");
					  if(maxlength.contains("22")) {
						  Reporter.SuccessReport("DBA name maxlength validation", "DBA name maxlength validation Passed");
						  Reporter.reportStep("Maxlength of Merchant DBA name field is :"+maxlength);
						  Reporter.reportStep("TestCase covered: TC44");
					  }else {
						  Reporter.failureReport("DBA name maxlength validation", "DBA name maxlength validation Passed");
					  }
					  
				  }
				// group merchant
				  if(GroupMerchant.length()>0){
					  waitForElementPresent(MMS_HomePage.GroupMerchant_txt,"Merchant DBA field Present");
					  click(MMS_HomePage.GroupMerchant_txt,"Merchant DBA field Present");
					  Thread.sleep(2000);
					 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					 
					  List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
				  
					  for(WebElement e: dropdown) {
					  String a = e.getText();
					      if(a.contains(GroupMerchant)) {
					    	  e.click();
					    	  Reporter.reportStep("GroupMerchant selected as :"+GroupMerchant);
					    	  Reporter.SuccessReport("GroupMerchant" +GroupMerchant, "GroupMerchant option is selected from dropdown");
					    	 
					    	  break;
					      }
					  }
						
					  Actions  action=new Actions(driver);
						
					  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 // driver.findElement(By.id("customer_display")).click();
					
					  
				  }
				  //parent name
				  
				  if(ParentMerchant.length()>0){
					  waitForElementPresent(MMS_HomePage.ParentMerchant,"Parent Merchant field Present");
					  click(MMS_HomePage.ParentMerchant,"Search Parent Merchant");
					  waitForElementPresent(MMS_HomePage.ParentMerchantName,"MerchantName search field Present");
					  type(MMS_HomePage.ParentMerchantName, ParentMerchant, "ParentMerchant");
					  Thread.sleep(1000);
					  waitForElementPresent(MMS_HomePage.ParentMerchant,"Parent Merchant field Present");
					  click(MMS_HomePage.MccSearchbtn,"Parent MerchantName search button clicked.");
					  Thread.sleep(2000);
					  waitForElementPresent(MMS_HomePage.ParentMerchantResult,"Parent Merchant field Present");
					  click(MMS_HomePage.ParentMerchantResult,"Parent MerchantName search result clicked.");
					  Reporter.reportStep("ParentMerchant selected as :"+ParentMerchant);
					  Reporter.reportStep("TestCase TC42,43 Passed.");
					  Reporter.SuccessReport("Parent Merchant", "Parent Merchant selected.");
					  
				  } 
				  
				
				//  MerchantLegalName
				  if(MerchantLegalName.length()>0){
					  waitForElementPresent(MMS_HomePage.MerchantLegalName,"Merchant DBA field Present");
					  click(MMS_HomePage.MerchantLegalName,MerchantLegalName);
					  type(MMS_HomePage.MerchantLegalName, MerchantLegalName, "MerchantLegalName");
					  Reporter.SuccessReport("MerchantLegalName", "MerchantLegalName field present.");
					  Reporter.SuccessReport("MerchantLegalName", "MerchantLegalName accepts alphanumeric characters.");
					  Reporter.reportStep("TC 45,46 passed.");
				  }
				  
				  //MerchantIdentification
				  if(MerchantIdentification.length()>0){
					  waitForElementPresent(MMS_HomePage.MerchantIdentification,"Merchant identification field Present");
					  click(MMS_HomePage.MerchantIdentification,"Merchant identification field Present");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
						  List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
						  ArrayList<String> arr3 = new ArrayList<String>();
						  
						  for(WebElement e: dropdown) {
							  String a = e.getText();
							  arr3.add(a);
						  }
						  

						  ArrayList<String> arr = new ArrayList<String>();
						  
						   for(WebElement e: dropdown) {
								  String a = e.getText();
								  arr.add(a);
								  
								  }
						
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(MerchantIdentification)) {
						    	  e.click();
						    	  Reporter.reportStep("Merchant Identification selected as :"+MerchantIdentification);
						    	  Reporter.reportStep("TestCase Pass: TC48");
						    	  break;
						      }
						  }
						  
						  if(arr3.contains("New") && arr3.contains("Old")) {

		                       Reporter.reportStep("Merchant Identification contains New & Old options.");

		                       Reporter.reportStep("TC 53 Pass.");

		                       Reporter.SuccessReport("Merchant Identification", "Merchant Identification validations pass.");

		              }else {

		            	  Reporter.failureReport("Merchant Identification", "Merchant Identification validations failed.");

		            	  Reporter.reportStep("TC 53 Fail.");

		              }
						  if(MerchantIdentification.contains("Old") && (MerchantIdentificationOldNo.length()>0)) {
								
                              waitForElementPresent(MMS_HomePage.MerchantIdentificationOldNo,"Merchant Identification Old No field Present");

                              click(MMS_HomePage.MerchantIdentificationOldNo,MerchantIdentificationOldNo);

                              type(MMS_HomePage.MerchantIdentificationOldNo, MerchantIdentificationOldNo, "Merchant Identification Old No");

                              

                              Reporter.reportStep("Merchant Identification Old No option is enabled.");

                              Reporter.reportStep("TC 54 Pass.");

                              Reporter.SuccessReport("Merchant Identification", "Merchant Identification Old No validations pass.");

						  }
						  
						  Actions  action=new Actions(driver);
						
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					  
					  //selectByVisibleText(MMS_HomePage.MerchantIdentification, MerchantIdentification, "MerchantIdentification");
					 
				  }
				  
				//MerchantClassification
				  if(MerchantClassification.length()>0){
					  waitForElementPresent(MMS_HomePage.MerchantClassification,"Merchant DBA field Present");
					  click(MMS_HomePage.MerchantClassification,"Merchant DBA field Present");
					  
					  //selectByVisibleText(MMS_HomePage.MerchantClassification, MerchantClassification, "Merchant Classification");
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
						  List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
						  
						  ArrayList<String> arr4 = new ArrayList<String>();
						  
						  for(WebElement e: dropdown) {
								
                              String a = e.getText();

                              arr4.add(a);

                       }
					  
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(MerchantClassification)) {
						    	  e.click();
						    	  Reporter.reportStep("Merchant Classification selected as :"+MerchantClassification);
						    	  break;
						      }
						  }
						  
						  if(arr4.contains("Retail") && arr4.contains("Corporate") && arr4.contains("Premium")) {
								
	                             
								
						        Reporter.reportStep("Merchant Classification dropdown contains Retail,Corporate & Premium options.");
							
						        Reporter.reportStep("TC 55 Pass.");
							
						        Reporter.SuccessReport("Merchant Classification", "Merchant Classification validations pass.");
							
						        }else {
							
						          Reporter.failureReport("Merchant Classification", "Merchant Classification validations failed.");
							
						          Reporter.reportStep("TC 55 Fail.");
							
						        }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
				  }
				  
				//Preffered language
				  if(PreferredLanguage.length()>0){
					  waitForElementPresent(MMS_HomePage.Prefferedlanguage,"Prefferedlanguage  field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, PreferredLanguage, "Merchant Classification");
					  click(MMS_HomePage.Prefferedlanguage,"Prefferedlanguage field Present");
					  

					  Reporter.reportStep("Preferred Language option.");
	
					  Reporter.SuccessReport("Preferred Language", "Preferred Language validations pass.");
	
					  Reporter.reportStep("TC 51 Pass.");
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
					   ArrayList<String> arr2 = new ArrayList<String>();
					   
					   for(WebElement e: dropdown) {
						   String a = e.getText();
						   arr2.add(a);
					   }
					   
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(PreferredLanguage)) {
						    	  e.click();
						    	  Reporter.reportStep("PreferredLanguage selected as :"+PreferredLanguage);
						    	  break;
						      }
						  }
						  
						  if(arr2.contains("Tamil") && arr2.contains("Telugu") &&  arr2.contains("English")) {
							  Reporter.reportStep("Preferred Language dropdown contains Tamil, Telugu and English options.");
							  
							  Reporter.reportStep("TC 52 Pass.");
							  Reporter.SuccessReport("Preferred Language", "Preferred Language validations pass.");
						  }else {
							  Reporter.failureReport("Preferred Language", "Preferred Language validations failed.");
							  Reporter.reportStep("TC 52 Fail.");
						  }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  // card acceptance
				  if(CardAcceptance.length()>0){
					  waitForElementPresent(MMS_HomePage.CardAcceptance,"CardAcceptance field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.CardAcceptance,"CardAcceptance field Present");
					  
					  Reporter.reportStep("Card Acceptance option available.");
					  Reporter.reportStep("TC 57 Pass.");
					  Reporter.SuccessReport("Card Acceptance", "Card Acceptance validations pass.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
					   ArrayList<String> arr6 = new ArrayList<String>();
					   
					   for(WebElement e: dropdown) {
						   String a = e.getText();
						   arr6.add(a);
					   }
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(CardAcceptance)) {
						    	  e.click();
						    	  Reporter.reportStep("Card Acceptance selected as :"+CardAcceptance);
						    	  break;
						      }
						  }
						  
						  if(arr6.contains("Domestic Only") && arr6.contains("International Only")
								  && arr6.contains("All Cards Accepted") && arr6.contains("Credit Only")
								  && arr6.contains("Debit Only") ) {
							  Reporter.SuccessReport("Card Acceptance", "Card Acceptance validations pass.");
							  Reporter.reportStep("Card Acceptance dropdown contains Domestic Only,International Only, "
							  		+ "All Cards Accepted,Credit Only,Debit Only options.");
							  Reporter.reportStep("TC 57,58 Pass.");
						  }else {
							  Reporter.failureReport("Card Acceptance", "Card Acceptance validations failed.");
							  Reporter.reportStep("TC 57,58 Fail.");
						  }
					    
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  //Agreement date
				  if(AggrementDate.length()>0){
					  waitForElementPresent(MMS_HomePage.AggrementDate,"AggrementDate field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.AggrementDate,"AggrementDate field Present");
					  Thread.sleep(2000);
					  Enter(MMS_HomePage.AggrementDate,"AggrementDate");
					  
				      Actions  action=new Actions(driver);
						
					  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
				  }
				  
				  //Merchant status
				  
			
				  if(MerchantStatus.length()>0){
					  waitForElementPresent(MMS_HomePage.MerchantStatus,"Merchant Status field Present");
					
					  click(MMS_HomePage.MerchantStatus,"MerchantStatus field clicked.");
					  Reporter.reportStep("Merchant Status option available.");
					  Reporter.reportStep("TC 60 Pass.");
					  Reporter.SuccessReport("Merchant Status", "Merchant Status validations pass.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
					   ArrayList<String> arr7 = new ArrayList<String>();
					   
					   for(WebElement e: dropdown) {
						   
						   String a = e.getText();
						   arr7.add(a);
					   }
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(MerchantStatus)) {
						    	  e.click();
						    	  Reporter.reportStep("MerchantStatus selected as :"+MerchantStatus);
						    	  break;
						      }
						  }
						  
						  if(arr7.contains("Application Received") && arr7.contains("Application Sent for Checker Approval")) {
							  Reporter.reportStep("Merchant Status dropdown contains both options.");
							  Reporter.reportStep("TC 61 Pass.");
							  Reporter.SuccessReport("Merchant Status", "Merchant Status validations pass.");
						  }else {
							  Reporter.failureReport("Merchant Status", "Merchant Status validations failed.");
							  Reporter.reportStep("TC 61 Fail.");
						  }
						  
						  
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  ///new to the world
				  if(NewtotheWorld.length()>0){
					  waitForElementPresent(MMS_HomePage.NewtotheWorld,"NewtotheWorld field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.NewtotheWorld,"NewtotheWorld field clicked.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
					   ArrayList<String> arr5 = new ArrayList<String>();
					   
					   for(WebElement e: dropdown) {
						   String a = e.getText();
						   arr5.add(a);
						   
					   }
					   
					   
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(NewtotheWorld)) {
						    	  e.click();
						    	  Reporter.reportStep("NewtotheWorld selected as :"+NewtotheWorld);
						    	  break;
						      }
						  }
						  
						  if(arr5.contains("Yes") && arr5.contains("No")) {
							  Reporter.reportStep("New to the World dropdown contains Yes & No options.");
							  Reporter.reportStep("TC 56 Pass.");
							  Reporter.SuccessReport("New to the World", "New to the World validations pass.");
						  }else {
							  Reporter.failureReport("New to the World", "New to the World validations failed.");
							  Reporter.reportStep("TC 56 Fail.");
						  }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  // firm pan number
				  if(FirmPanNumber.length()>0){
					  waitForElementPresent(MMS_HomePage.FirmPanNumber,"Merchant DBA field Present");
					  type(MMS_HomePage.FirmPanNumber, FirmPanNumber, "Merchant DBA Name");
					  
				  }
				  
				// RM name
				  if(RMName.length()>0){
					  waitForElementPresent(MMS_HomePage.RMName,"Merchant DBA field Present");
					  type(MMS_HomePage.RMName, RMName, "Merchant DBA Name");
					  Reporter.reportStep("RM Name field present.");
					  Reporter.SuccessReport("RM Name field validations", "RM Name field validations Pass");
					  Reporter.reportStep("TestCase 59 Passed.");
					  
					  
					  
				  }
				  
				  // RM code
				  if(RMCode.length()>0){
					  waitForElementPresent(MMS_HomePage.RMCode,"Merchant DBA field Present");
					  type(MMS_HomePage.RMCode, RMCode, "Merchant DBA Name");
					  
				  }
				  
				  //ME segment
				  if(MESegment.length()>0){
					  scrollDown();
					  waitForElementPresent(MMS_HomePage.MESegment,"MESegment field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.MESegment,"MESegment field clicked.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(MESegment)) {
						    	  e.click();
						    	  Reporter.reportStep("MESegment selected as :"+MESegment);
						    	  break;
						      }
						  }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  //Business entity
				  
				  if(BusinessEntity.length()>0){
					  //scrolltoElement(MMS_HomePage.BusinessEntity);
					  waitForElementPresent(MMS_HomePage.BusinessEntity,"BusinessEntity field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.BusinessEntity,"BusinessEntity field clicked.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
					   ArrayList<String> arr = new ArrayList<String>();
						  
						for(WebElement e: dropdown) {
								  String a = e.getText();
								  arr.add(a);
								  
								  }
					   
					   
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(BusinessEntity)) {
						    	  e.click();
						    	  Reporter.reportStep("BusinessEntity selected as :"+BusinessEntity);
						    	  break;
						      }
						  }
						  
						  if(arr.contains("Sole Proprietorship") && arr.contains("Partnership")&&
								  arr.contains("Others") && arr.contains("Society")&&
								  arr.contains("Trust") && arr.contains("Professionals")&&
								  arr.contains("Small Vendors") && arr.contains("Private Limited Company")&&
								  arr.contains("Public Limited Company")) {
							  Reporter.SuccessReport("BusinessEntity", "BusinessEntity validations pass.");
							  Reporter.reportStep("BusinessEntit dropdown contains Sole Proprietorship,Partnership,Others,Society,Trust,Professionals,Small Vendors,Private Limited Company,Public Limited Company options.");
							  Reporter.reportStep("TC 65 Pass.");
						  }else {
							  Reporter.failureReport("BusinessEntity", "BusinessEntity validations failed.");
							  Reporter.reportStep("TC 65 Fail.");
						  }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  // monthly limit
				  if(MonthlyLimit.length()>0){
					  //scrolltoElement(MMS_HomePage.MonthlyLimit);
					  waitForElementPresent(MMS_HomePage.MonthlyLimit,"MonthlyLimit field Present");
					  type(MMS_HomePage.MonthlyLimit, MonthlyLimit, "Monthly Limit");
					  Reporter.reportStep("Monthly Limit Option - TC 78 Pass");
					  Reporter.SuccessReport("Monthly Limit validations", "Monthly Limit validations Pass");
					  System.out.println("Monthly Limit option to change the monthly Limit");
					  
				  }
				  
				  // risk approval waiver
				  if(RiskApprovalWaiver.length()>0){
					  //scrolltoElement(MMS_HomePage.RiskApprovalWaive);
					  waitForElementPresent(MMS_HomePage.RiskApprovalWaive,"BusinessEntity field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.RiskApprovalWaive,"BusinessEntity field clicked.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					   ArrayList<String> arr8 = new ArrayList<String>();
					   
					   for(WebElement e: dropdown) {
						   String a = e.getText();
						   arr8.add(a);
					   }
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(RiskApprovalWaiver)) {
						    	  e.click();
						    	  Reporter.reportStep("RiskApprovalWaiver selected as :"+RiskApprovalWaiver);
						    	  break;
						      }
						  }
						  
						  if(arr8.contains("Yes") && arr8.contains("No")) {
							  
							  Reporter.reportStep("Risk Approval Waiver dropdown contains Yes and No options.");
							  Reporter.reportStep("TC 72 Pass.");
							  Reporter.SuccessReport("Risk Approval Waiver", "Risk Approval Waiver validations pass.");
						  }else {
							  Reporter.failureReport("Risk Approval Waiver", "Risk Approval Waiver validations failed.");
							  Reporter.reportStep("TC 72 Fail.");
							  
						  }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  // MCC
				  if(MCC.length()>0){
					  //scrolltoElement(MMS_HomePage.RiskApprovalWaive);
					  waitForElementPresent(MMS_HomePage.Mcc,"Mcc field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.Mcc,"Mcc field clicked.");
					  
					  Thread.sleep(2000);
					  
					  waitForElementPresent(MMS_HomePage.MccSearch,"Mcc search field Present");
					  type(MMS_HomePage.MccSearch, MCC, "MCC");
					  Thread.sleep(2000);
					  click(MMS_HomePage.MccSearchbtn,"MccSearchbtn field clicked.");
					  Thread.sleep(2000);
					  waitForElementPresent(MMS_HomePage.MccSearchResult1,"Mcc search result field Present");
					  click(MMS_HomePage.MccSearchResult1,"Mcc result field clicked.");
					  
				  }
				  
				  //scheme baclist check
				  if(SchemeBacklistCheck.length()>0){
					  //scrolltoElement(MMS_HomePage.RiskApprovalWaive);
					  waitForElementPresent(MMS_HomePage.SchemeBacklistCheck,"BusinessEntity field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.SchemeBacklistCheck,"SchemeBacklistCheck field clicked.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(SchemeBacklistCheck)) {
						    	  e.click();
						    	  Reporter.reportStep("SchemeBacklistCheck selected as :"+SchemeBacklistCheck);
						    	  break;
						      }
						  }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  // daily limit
				  // monthly limit
				  if(DailyLimit.length()>0){
					  //scrolltoElement(MMS_HomePage.MonthlyLimit);
					  waitForElementPresent(MMS_HomePage.DailyLimit,"DailyLimit field Present");
					  type(MMS_HomePage.DailyLimit, DailyLimit, "Daily Limit");
					  Reporter.reportStep("Daily Limit Option - TC 79 & TC 80 Pass");
					  Reporter.SuccessReport("Daily Limit validations", "Daily Limit validations Pass");
					  System.out.println("Daily Limit option to change the Daily Limit");
					  
				  }
				  
				  //per transacton limit
				  // monthly limit
				  if(PertxnLimit.length()>0){
					  //scrolltoElement(MMS_HomePage.MonthlyLimit);
					  waitForElementPresent(MMS_HomePage.PerTransactionLimit,"Per transaction field Present");
					  String defaultpertxn= driver.findElement(MMS_HomePage.PerTransactionLimit).getAttribute("value");
					  Reporter.reportStep("Per transaction limit default value is :"+defaultpertxn);
					  Reporter.reportStep("TestCase 83 Pass.");
					  Reporter.SuccessReport("Per transaction limit default value", "Per transaction limit default value is present.");
					  type(MMS_HomePage.PerTransactionLimit, PertxnLimit, "Per transaction Limit");
					  Reporter.SuccessReport("PerTransactionLimit", "PerTransactionLimit field present.");
					  Reporter.reportStep("TestCase 82 Pass.");
					  
				  }
				  scrollDown();
				  //FIRC frequency
				  if(FIRCFrequency.length()>0){
					  //scrolltoElement(MMS_HomePage.RiskApprovalWaive);
					  waitForElementPresent(MMS_HomePage.FIRCFrequency,"BusinessEntity field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.FIRCFrequency,"FIRCFrequency field clicked.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
					   ArrayList<String> arr = new ArrayList<String>();
					  
					   for(WebElement e: dropdown) {
							  String a = e.getText();
							  arr.add(a);
							  
							  }
					   
					   
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						 
						      if(a.contains(FIRCFrequency)) {
						    	  e.click();
						    	  Reporter.reportStep("FIRCFrequency selected as :"+FIRCFrequency);
						    	  break;
						      }
						  }
						  
						  
						  if(arr.contains("DAILY") && arr.contains("MONTHLY")) {
							  Reporter.SuccessReport("FIRC Frequency", "FIRC Frequency validations pass.");
							  Reporter.reportStep("FIRC dropdown contains Daily and Monthly options.");
							  Reporter.reportStep("TC 17 Pass.");
						  }else {
							  Reporter.failureReport("FIRC Frequency", "FIRC Frequency validations failed.");
							  Reporter.reportStep("TC 17 Fail.");
						  }
						  
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  //test
				  //Branch
				  if(BranchCode.length()>0){
					  //scrolltoElement(MMS_HomePage.RiskApprovalWaive);
					  waitForElementPresent(MMS_HomePage.Branch,"Branch field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.Branch,"Branch field clicked.");
					  
					  Thread.sleep(2000);
					  
					  waitForElementPresent(MMS_HomePage.BranchCode,"BranchCode search field Present");
					  type(MMS_HomePage.BranchCode, BranchCode, "Branch");
					  click(MMS_HomePage.BranchSearchbtn,"BranchSearchbtn field clicked.");
					  Reporter.reportStep("Option to input branch code");
					  Reporter.SuccessReport("Branch Code validations", "Branch Code validations Pass");
					  System.out.println("Option is available to input branch code");
					  
					  Thread.sleep(2000);
					  waitForElementPresent(MMS_HomePage.BranchSearchResult1,"Branch search result field Present");
					  click(MMS_HomePage.BranchSearchResult1,"Branch result field clicked.");
					  
					  Reporter.SuccessReport("Branch Selection", "Branch selection done using search branch code.");
					  Reporter.reportStep("TestCase TC 85 passed.");
					  
					  Thread.sleep(2000);
					 
					  String c= driver.findElement(By.id("branch_display")).getAttribute("value");
					  
					  String branchname= data.get("BranchName");
					  
					  if(c.contains(branchname)) {
						  Reporter.reportStep("Branch name visible on the UI is:"+c);
						  Reporter.SuccessReport("Branch Validation", "Branch Name is visible on the UI.");
						  Reporter.reportStep("TestCase 30 Passed.");
					  }

					  
				  }
				  
				  //Average monthly balance
				  if(AverageMonthlyBalance.length()>0){
					  //scrolltoElement(MMS_HomePage.MonthlyLimit);
					  waitForElementPresent(MMS_HomePage.AverageMonthlyBalance,"Per transaction field Present");
					  type(MMS_HomePage.AverageMonthlyBalance, AverageMonthlyBalance, "Per transaction Limit");
					  
				  }
				  
				  // ecommerce 
				 
				  if(EcommerceIndicator.length()>0){
					  //scrolltoElement(MMS_HomePage.RiskApprovalWaive);
					  waitForElementPresent(MMS_HomePage.EcommerceIndicator,"EcommerceIndicator field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.EcommerceIndicator,"EcommerceIndicator field clicked.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(EcommerceIndicator)) {
						    	  e.click();
						    	  Reporter.reportStep("EcommerceIndicator selected as :"+EcommerceIndicator);
						    	  break;
						      }
						  }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  //promo code
				  if(PromoCode.length()>0){
					  //scrolltoElement(MMS_HomePage.MonthlyLimit);
					  waitForElementPresent(MMS_HomePage.PromoCode,"PromoCode field Present");
					  type(MMS_HomePage.PromoCode, PromoCode, "PromoCode");
					  
				  }
				  
				}
				  
	}
	
	/*
	public static void fillMerchantDetailsNegative(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
				Reporter.reportStep("Merchant Details");
		// data from excel sheet
				String ApplicationSource = data.get("ApplicationSource");
				String ApplicationNumber = data.get("ApplicationNumber");
				String MerchantDBAName = data.get("MerchantDBAName");
				String GroupMerchant = data.get("GroupMerchant");
				String MerchantLegalName = data.get("MerchantLegalName");
				String MerchantIdentification = data.get("MerchantIdentification");
				String MerchantClassification = data.get("MerchantClassification");
				String MerchantIdentificationOldNo  = data.get("MerchantIdentificationOldNo");
				
				String PreferredLanguage = data.get("PreferredLanguage");
				String CardAcceptance = data.get("CardAcceptance");
				String AggrementDate = data.get("AggrementDate"); 
				String MerchantStatus = data.get("MerchantStatus"); 
				String NewtotheWorld = data.get("NewtotheWorld");  
				String FirmPanNumber = data.get("FirmPanNumber"); 
				String RMName = data.get("RMName"); 
				String RMCode = data.get("RMCode"); 
				String MESegment = data.get("MESegment"); 
				String BusinessEntity = data.get("BusinessEntity"); 
				String MonthlyLimit = data.get("MonthlyLimit");  
				String RiskApprovalWaiver = data.get("RiskApprovalWaiver");
				String MCC = data.get("MCC"); 
				String SchemeBacklistCheck = data.get("SchemeBacklistCheck"); 
				String DailyLimit = data.get("DailyLimit");
				String PertxnLimit = data.get("PerTransactionLimit"); 
				String FIRCFrequency = data.get("FIRCFrequency"); 
				String BranchCode = data.get("BranchCode"); 
				String AverageMonthlyBalance = data.get("AverageMonthlyBalance");
				String EcommerceIndicator = data.get("EcommerceIndicator"); 
				String PromoCode = data.get("PromoCode");
//				
//				
//		
				
				//Application source
				if (waitForElementPresent(MMS_HomePage.AppnSource_drp,"Application source dropdown Present"))
				{
					//change added
					Reporter.reportStep("Application source dropdown Present");
					click(MMS_HomePage.AppnSource_drp,"Application Source field Present");
					
					 List<WebElement> AppnSource_drpdropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					
					 for(WebElement e: AppnSource_drpdropdown) {
						 String a = e.getText();
						 if(a.contains(ApplicationSource)) {
							 e.click();
							 Reporter.SuccessReport("ApplicationSource" +ApplicationSource, "Application source option is selected from dropdown"); 
							 System.out.println("Application source " +ApplicationSource+ " option is selected from dropdown");
							 break;
						 }else {
							 Reporter.failureReport("ApplicationSource", "Application source option is not selected from dropdown"); 
							 System.out.println("Application source " +ApplicationSource+ " is not selected from dropdown");
						 }
					 }
					
					
					//selectByVisibleText(MMS_HomePage.AppnSource_drp, ApplicationSource, "application source");
				}
				
				//Application number
				  if(ApplicationNumber.length()>0){
					  waitForElementPresent(MMS_HomePage.AppnNumber_txt,"Application number field Present");
					  type(MMS_HomePage.AppnNumber_txt, "@@@@@", "Application number");
					  
					  driver.findElement(MMS_HomePage.AppnNumber_txt).sendKeys(Keys.TAB);
					
					  
					  Thread.sleep(1000);
				
					  if(driver.getPageSource().contains("Allowed only alpha and numeric values."))
					  {
						  Reporter.reportStep("Application number field accepts only alphanumeric characters");
						  Reporter.SuccessReport("Application number validations", "Application number validations Pass");
						 Reporter.reportStep("TestCase Passed: TC39");
					  }
					  
					  
				  }
				  
				  //Merchant DBA Name
				  if(GroupMerchant.length()>0){
					 
					  waitForElementPresent(MMS_HomePage.MerchantDBAname_txt,"Merchant DBA field Present");
					  //type(MMS_HomePage.MerchantDBAname_txt, MerchantDBAName, "Merchant DBA Name");
					  type(MMS_HomePage.MerchantDBAname_txt, "############", "Merchant DBA Name");
					  driver.findElement(MMS_HomePage.MerchantDBAname_txt).sendKeys(Keys.TAB);
					
					  
					  Thread.sleep(1000);
				
					  if(driver.getPageSource().contains("Special characters are  not allowed."))
					  {
						  Reporter.reportStep("GroupMerchant does not allow special characters.");
						  Reporter.SuccessReport("GroupMerchant validations", "GroupMerchant validations Pass");
						  System.out.println("GroupMerchant does not allow special characters");
					  }
				  }
				
				
				// group merchant
				  if(GroupMerchant.length()>0){
					  waitForElementPresent(MMS_HomePage.GroupMerchant_txt,"Merchant DBA field Present");
					  click(MMS_HomePage.GroupMerchant_txt,"Merchant DBA field Present");
					  Thread.sleep(2000);
					 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					 
					  List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
				  
					  for(WebElement e: dropdown) {
					  String a = e.getText();
					      if(a.contains(GroupMerchant)) {
					    	  e.click();
					    	  Reporter.reportStep("GroupMerchant selected as :"+GroupMerchant);
					    	 
					    	  break;
					      }else {
					    	  Reporter.failureReport("GroupMerchant", "Group Merchant option is not selected from dropdown"); 
					    	  System.out.println("Group Merchant" +GroupMerchant+ " is not selected from dropdown");
					      }
					  }
						
					  Actions  action=new Actions(driver);
						
					  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 // driver.findElement(By.id("customer_display")).click();
					
					  
				  }
				//  MerchantLegalName
				  if(MerchantLegalName.length()>0){
					  waitForElementPresent(MMS_HomePage.MerchantLegalName,"Merchant DBA field Present");
					  click(MMS_HomePage.MerchantLegalName,MerchantLegalName);
					  type(MMS_HomePage.MerchantLegalName, "@@@@@@", "MerchantLegalName");
					  
					  driver.findElement(MMS_HomePage.MerchantLegalName).sendKeys(Keys.TAB);
					
					  
					  Thread.sleep(1000);
				
					  if(driver.getPageSource().contains("Special characters are  not allowed."))
					  {
						  Reporter.reportStep("MerchantLegalName does not allow special characters.");
						  Reporter.SuccessReport("MerchantLegalName validations", "GroupMerchant validations Pass");
						  System.out.println("MerchantLegalName does not allow special characters");
						  Reporter.reportStep("TestCase Pass: TC 47.");
					  }
					  
				  }
				  //MerchantIdentification
				  if(MerchantIdentification.length()>0){
					  waitForElementPresent(MMS_HomePage.MerchantIdentification,"Merchant identification field Present");
					  click(MMS_HomePage.MerchantIdentification,"Merchant identification field Present");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
						  List<WebElement> dropdown1= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
						  for(WebElement e: dropdown1) {
						  String a = e.getText();
						      if(a.contains(MerchantIdentification)) {
						    	  e.click();
						    	  Reporter.reportStep("Merchant Identification selected as :"+MerchantIdentification);
						    	  break;
						      }
						  }
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					  
					  //selectByVisibleText(MMS_HomePage.MerchantIdentification, MerchantIdentification, "MerchantIdentification");
						  if(MerchantIdentification.contains("Old") && (MerchantIdentificationOldNo.length()>0)) {
							  waitForElementPresent(MMS_HomePage.MerchantIdentificationOldNo,"Merchant Identification Old No field Present");
							  click(MMS_HomePage.MerchantIdentificationOldNo,MerchantIdentificationOldNo);
							  
							  type(MMS_HomePage.MerchantIdentificationOldNo, MerchantIdentificationOldNo, "Merchant Identification Old No");
							  Reporter.reportStep("Merchant Identification Old No option is enabled.");
							  Reporter.reportStep("TC 54 Pass.");
							  Reporter.SuccessReport("Merchant Identification", "Merchant Identification Old No validations pass.");
							  
							  
						  }else {
							  Reporter.failureReport("Merchant Identification", "Merchant Identification Old No validations failed.");
							  Reporter.reportStep("TC 54 Fail.");
						  }
						  
						  if(dropdown1.contains("New") && dropdown1.contains("Old")) {
							  Reporter.reportStep("Merchant Identification contains New & Old options.");
							  Reporter.reportStep("TC 53 Pass.");
							  Reporter.SuccessReport("Merchant Identification", "Merchant Identification validations pass.");
							  
						  
						  }else {
							  Reporter.failureReport("Merchant Identification", "Merchant Identification validations failed.");
							  Reporter.reportStep("TC 53 Fail.");
						  }
						  
					 
				  }
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				//MerchantClassification
				  if(MerchantClassification.length()>0){
					  waitForElementPresent(MMS_HomePage.MerchantClassification,"Merchant DBA field Present");
					  click(MMS_HomePage.MerchantClassification,"Merchant DBA field Present");
					  
					  //selectByVisibleText(MMS_HomePage.MerchantClassification, MerchantClassification, "Merchant Classification");
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
						  List<WebElement> dropdown2= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
						  
						  ArrayList<String> arr4 = new ArrayList<String>(); 
						  
						  for(WebElement e: dropdown2) {
							  String a = e.getText();
							  arr4.add(a);
						  }
						
						  
						  for(WebElement e: dropdown2) {
						  String a = e.getText();
						      if(a.contains(MerchantClassification)) {
						    	  e.click();
						    	  Reporter.reportStep("Merchant Classification selected as :"+MerchantClassification);
						    	  break;
						      }
						  }
						  
						  if(arr4.contains("Retail") && arr4.contains("Corporate") && arr4.contains("Premium")) {
							  Reporter.reportStep("Merchant Classification dropdown contains Retail,Corporate & Premium options.");
							  Reporter.reportStep("TC 55 Pass.");
							  Reporter.SuccessReport("Merchant Classification", "Merchant Classification validations pass.");
						  }else {
							  Reporter.failureReport("Merchant Classification", "Merchant Classification validations failed.");
							  Reporter.reportStep("TC 55 Fail.");
						  }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
				  }
				  
				//Preffered language
				  if(PreferredLanguage.length()>0){
					  waitForElementPresent(MMS_HomePage.Prefferedlanguage,"Merchant DBA field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, PreferredLanguage, "Merchant Classification");
					  click(MMS_HomePage.Prefferedlanguage,"Merchant DBA field Present");
					  Reporter.reportStep("Preferred Language option.");
					  Reporter.SuccessReport("Preferred Language", "Preferred Language validations pass.");
					  Reporter.reportStep("TC 51 Pass.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown3= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
					   ArrayList<String> arr2 = new ArrayList<String>();
					   
					   for(WebElement e: dropdown3) {
						   String a = e.getText();
						   arr2.add(a);
					   }
					   
						  for(WebElement e: dropdown3) {
						  String a = e.getText();
						      if(a.contains(PreferredLanguage)) {
						    	  e.click();
						    	  Reporter.reportStep("PreferredLanguage selected as :"+PreferredLanguage);
						    	  break;
						      }
						  }
						  
						  if(arr2.contains("Tamil") && arr2.contains("Telugu") &&  arr2.contains("English")) {
							  Reporter.reportStep("Preferred Language dropdown contains Tamil, Telugu and English options.");
							  
							  Reporter.reportStep("TC 52 Pass.");
							  Reporter.SuccessReport("Preferred Language", "Preferred Language validations pass.");
						  }else {
							  Reporter.failureReport("Preferred Language", "Preferred Language validations failed.");
							  Reporter.reportStep("TC 52 Fail.");
						  }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  // card acceptance
				  if(CardAcceptance.length()>0){
					  waitForElementPresent(MMS_HomePage.CardAcceptance,"CardAcceptance field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.CardAcceptance,"CardAcceptance field Present");
					  Reporter.reportStep("Card Acceptance option available.");
					  Reporter.reportStep("TC 57 Pass.");
					  Reporter.SuccessReport("Card Acceptance", "Card Acceptance validations pass.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown4= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
					   
						 
					   ArrayList<String> arr = new ArrayList<String>();
						  
					   for(WebElement e: dropdown4) {
							  String a = e.getText();
							  arr.add(a);
							  
							  }
					   
					   
					   
					   for(WebElement e: dropdown4) {
						  String a = e.getText();
						      if(a.contains(CardAcceptance)) {
						    	  e.click();
						    	  Reporter.reportStep("Card Acceptance selected as :"+CardAcceptance);
						    	  break;
						      }
						  }
						  

						  if(arr.contains("Domestic Only") && arr.contains("International Only")
								  && arr.contains("All Cards Accepted") && arr.contains("Credit Only")
								  && arr.contains("Debit Only") ) {
							  Reporter.SuccessReport("Card Acceptance", "Card Acceptance validations pass.");
							  Reporter.reportStep("Card Acceptance dropdown contains Domestic Only,International Only, "
							  		+ "All Cards Accepted,Credit Only,Debit Only options.");
							  Reporter.reportStep("TC 57,58 Pass.");
						  }else {
							  Reporter.failureReport("Card Acceptance", "Card Acceptance validations failed.");
							  Reporter.reportStep("TC 57,58 Fail.");
						  }
					   
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  //Agreement date
				  if(AggrementDate.length()>0){
					  waitForElementPresent(MMS_HomePage.AggrementDate,"AggrementDate field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.AggrementDate,"AggrementDate field Present");
					  Thread.sleep(2000);
					  Enter(MMS_HomePage.AggrementDate,"AggrementDate");
					  
				      Actions  action=new Actions(driver);
						
					  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
				  }
				  
				  //Merchant status
				  
			
				  if(MerchantStatus.length()>0){
					  waitForElementPresent(MMS_HomePage.MerchantStatus,"Merchant Status field Present");
					
					  click(MMS_HomePage.MerchantStatus,"MerchantStatus field clicked.");
					  Reporter.reportStep("Merchant Status option available.");
					  
					  Reporter.reportStep("TC 60 Pass.");
						
	                  Reporter.SuccessReport("Merchant Status", "Merchant Status validations pass.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
					   ArrayList<String> arr = new ArrayList<String>();
						  
						for(WebElement e: dropdown) {
								  String a = e.getText();
								  arr.add(a);
								  
								  }
					   
					   
					   
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(MerchantStatus)) {
						    	  e.click();
						    	  Reporter.reportStep("MerchantStatus selected as :"+MerchantStatus);
						    	  Reporter.reportStep("Merchant Status option available.");
						    	  Reporter.reportStep("TC 60 Pass.");
						    	  Reporter.SuccessReport("Merchant Status", "Merchant Status validations pass.");
						    	  break;
						      }
						  }
						  
						  if(arr.contains("Application Received") && arr.contains("Application Sent for Checker Approval")) {
							  Reporter.SuccessReport("MerchantStatus", "MerchantStatus validations pass.");
							  Reporter.reportStep("MerchantStatus dropdown contains Application Received and Application Sent for Checker Approval options.");
							  Reporter.reportStep("TC 60,61 Pass.");
						  }else {
							  Reporter.failureReport("FIRC Frequency", "FIRC Frequency validations failed.");
							  Reporter.reportStep("TC 60,61 Fail.");
						  }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  //new to the world
				  if(NewtotheWorld.length()>0){
					  waitForElementPresent(MMS_HomePage.NewtotheWorld,"NewtotheWorld field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.NewtotheWorld,"NewtotheWorld field clicked.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
					   ArrayList<String> arr5 = new ArrayList<String>();
					   
					   for(WebElement e: dropdown) {
						   String a = e.getText();
						   arr5.add(a);
						   
					   }
					   
					   
					   
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(NewtotheWorld)) {
						    	  e.click();
						    	  Reporter.reportStep("NewtotheWorld selected as :"+NewtotheWorld);
						    	  break;
						      }
						  }
						  
						  
						  if(arr5.contains("Yes") && arr5.contains("No")) {
							  Reporter.reportStep("New to the World dropdown contains Yes & No options.");
							  Reporter.reportStep("TC 56 Pass.");
							  Reporter.SuccessReport("New to the World", "New to the World validations pass.");
						  }else {
							  Reporter.failureReport("New to the World", "New to the World validations failed.");
							  Reporter.reportStep("TC 56 Fail.");
						  }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  // firm pan number
				  if(FirmPanNumber.length()>0){
					  waitForElementPresent(MMS_HomePage.FirmPanNumber,"Merchant DBA field Present");
					  type(MMS_HomePage.FirmPanNumber, "AAAAAAA", "Merchant DBA Name");
					  
					  driver.findElement(MMS_HomePage.FirmPanNumber).sendKeys(Keys.TAB);
					
					  
					  Thread.sleep(1000);
				
					  if(driver.getPageSource().contains("Please enter the valid PAN Number"))
					  {
						  Reporter.reportStep("Firm PAN Number does not allow invalid PAN number");
						  Reporter.SuccessReport("Firm PAN Number validations", "Firm PAN Number validations Pass");
						  System.out.println("Firm PAN Number does not allow invalid PAN number");
					  }
					  
				  }
				  
				  // RM name
				  if(RMName.length()>0){
					  waitForElementPresent(MMS_HomePage.RMName,"Merchant DBA field Present");
					  type(MMS_HomePage.RMName, RMName, "Merchant DBA Name");
					  Reporter.reportStep("RM Name field present.");
					  Reporter.SuccessReport("RM Name field validations", "RM Name field validations Pass");
					  Reporter.reportStep("TestCase 59 Passed.");
					  
					  
					  
				  }
				  
				  // RM code
				  if(RMCode.length()>0){
					  waitForElementPresent(MMS_HomePage.RMCode,"Merchant DBA field Present");
					  type(MMS_HomePage.RMCode, RMCode, "Merchant DBA Name");
					  
				  }
				  
				  //ME segment
				  if(MESegment.length()>0){
					  scrollDown();
					  waitForElementPresent(MMS_HomePage.MESegment,"MESegment field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.MESegment,"MESegment field clicked.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
					   ArrayList<String> arr = new ArrayList<String>();
						  
						for(WebElement e: dropdown) {
								  String a = e.getText();
								  arr.add(a);
								  
								  }  
					   
					   
					   
					   
					   for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(MESegment)) {
						    	  e.click();
						    	  Reporter.reportStep("MESegment selected as :"+MESegment);
						    	  break;
						      }
						  }
						  
					   if(arr.contains("Standard") && arr.contains("Gold")&&
							   arr.contains("Platinum") && arr.contains("Silver") && arr.contains("Premium")) {
							  Reporter.SuccessReport("MESegment", "MESegment validations pass.");
							  Reporter.reportStep("MESegment dropdown contains Daily and Monthly options.");
							  Reporter.reportStep("TC 62 Pass.");
						  }else {
							  Reporter.failureReport("MESegment", "MESegment validations failed.");
							  Reporter.reportStep("TC 62 Fail.");
						  }
					   
					   
					   
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  //Business entity
				  
				  if(BusinessEntity.length()>0){
					  //scrolltoElement(MMS_HomePage.BusinessEntity);
					  waitForElementPresent(MMS_HomePage.BusinessEntity,"BusinessEntity field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.BusinessEntity,"BusinessEntity field clicked.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
					   ArrayList<String> arr8 = new ArrayList<String>();
					   for(WebElement e: dropdown) {
						   String a = e.getText();
						   arr8.add(a);
						   
					   }
					   
					   
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(BusinessEntity)) {
						    	  e.click();
						    	  Reporter.reportStep("BusinessEntity selected as :"+BusinessEntity);
						    	  break;
						      }
						  }
						  
						  if(arr8.contains("Sole Proprietorship") && arr8.contains("Partnership")&& 
								  arr8.contains("Others")&& arr8.contains("Society")&& arr8.contains("Trust")&&
								  arr8.contains("Professionals")&& arr8.contains("Small Vendors")&& 
								  arr8.contains("Private Limited Company")&& arr8.contains("Public Limited Company")) {
							  Reporter.reportStep("Business entity dropdown contains Sole Proprietorship ,Partnership,Others,Society,Trust,Professionals,Small Vendors,Private Limited Company & Public Limited Company options.");
							  Reporter.reportStep("TC 65 Pass.");
							  
							  Reporter.SuccessReport("Business Entity", "Business Entity validations pass.");
							  
							  
						  }else {
							  Reporter.failureReport("Business Entity", "Business Entity validations failed.");
							  Reporter.reportStep("TC 65 Fail.");
						  }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  // monthly limit
				  if(MonthlyLimit.length()>0){
					  //scrolltoElement(MMS_HomePage.MonthlyLimit);
					  waitForElementPresent(MMS_HomePage.MonthlyLimit,"MonthlyLimit field Present");
					  type(MMS_HomePage.MonthlyLimit, MonthlyLimit, "Monthly Limit");
					  
				  }
				  
				  // risk approval waiver
				  if(RiskApprovalWaiver.length()>0){
					  //scrolltoElement(MMS_HomePage.RiskApprovalWaive);
					  waitForElementPresent(MMS_HomePage.RiskApprovalWaive,"BusinessEntity field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.RiskApprovalWaive,"BusinessEntity field clicked.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(RiskApprovalWaiver)) {
						    	  e.click();
						    	  Reporter.reportStep("RiskApprovalWaiver selected as :"+RiskApprovalWaiver);
						    	  break;
						      }
						  }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  // MCC
				  if(MCC.length()>0){
					  //scrolltoElement(MMS_HomePage.RiskApprovalWaive);
					  waitForElementPresent(MMS_HomePage.Mcc,"Mcc field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.Mcc,"Mcc field clicked.");
					  
					  Thread.sleep(2000);
					  
					  waitForElementPresent(MMS_HomePage.MccSearch,"Mcc search field Present");
					  type(MMS_HomePage.MccSearch, MCC, "MCC");
					  click(MMS_HomePage.MccSearchbtn,"MccSearchbtn field clicked.");
					  Thread.sleep(2000);
					  waitForElementPresent(MMS_HomePage.MccSearchResult1,"Mcc search result field Present");
					  click(MMS_HomePage.MccSearchResult1,"Mcc result field clicked.");
					  
				  }
				  
				  //scheme baclist check
				  if(SchemeBacklistCheck.length()>0){
					  //scrolltoElement(MMS_HomePage.RiskApprovalWaive);
					  waitForElementPresent(MMS_HomePage.SchemeBacklistCheck,"BusinessEntity field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.SchemeBacklistCheck,"SchemeBacklistCheck field clicked.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(SchemeBacklistCheck)) {
						    	  e.click();
						    	  Reporter.reportStep("SchemeBacklistCheck selected as :"+SchemeBacklistCheck);
						    	  break;
						      }
						  }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  // daily limit
				  // monthly limit
				  if(DailyLimit.length()>0){
					  //scrolltoElement(MMS_HomePage.MonthlyLimit);
					  waitForElementPresent(MMS_HomePage.DailyLimit,"DailyLimit field Present");
					  type(MMS_HomePage.DailyLimit, DailyLimit, "Daily Limit");
					  
				  }
				  
				  //per transacton limit
				  // monthly limit
				  if(PertxnLimit.length()>0){
					  //scrolltoElement(MMS_HomePage.MonthlyLimit);
					  waitForElementPresent(MMS_HomePage.PerTransactionLimit,"Per transaction field Present");
					  type(MMS_HomePage.PerTransactionLimit, PertxnLimit, "Per transaction Limit");
					  
				  }
				  scrollDown();
				  //FIRC frequency
				  if(FIRCFrequency.length()>0){
					  //scrolltoElement(MMS_HomePage.RiskApprovalWaive);
					  waitForElementPresent(MMS_HomePage.FIRCFrequency,"BusinessEntity field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.FIRCFrequency,"FIRCFrequency field clicked.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(FIRCFrequency)) {
						    	  e.click();
						    	  Reporter.reportStep("FIRCFrequency selected as :"+FIRCFrequency);
						    	  break;
						      }
						  }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  //Branch
				  if(BranchCode.length()>0){
					  //scrolltoElement(MMS_HomePage.RiskApprovalWaive);
					  waitForElementPresent(MMS_HomePage.Branch,"Branch field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.Branch,"Branch field clicked.");
					  
					  Thread.sleep(2000);
					  
					  waitForElementPresent(MMS_HomePage.BranchCode,"BranchCode search field Present");
					  type(MMS_HomePage.BranchCode, BranchCode, "Branch");
					  click(MMS_HomePage.BranchSearchbtn,"BranchSearchbtn field clicked.");
					  
					  Reporter.reportStep("Option to input branch code");
					  Reporter.SuccessReport("Branch Code validations", "Branch Code validations Pass");
					  
					  Thread.sleep(2000);
					  waitForElementPresent(MMS_HomePage.BranchSearchResult1,"Branch search result field Present");
					  click(MMS_HomePage.BranchSearchResult1,"Branch result field clicked.");
					  
					  Thread.sleep(2000);
					  String c= driver.findElement(By.id("branch_display")).getAttribute("value");
					  String branchname= data.get("BranchName");
					  
					  if(c.contains(branchname)) {
						  Reporter.reportStep("Branch name visible on the UI is:"+c);
						  Reporter.SuccessReport("Branch Validation", "Branch Name is visible on the UI.");
						  Reporter.reportStep("TestCase 30 Passed.");
					  }
					  
				  }
				  
				  //Average monthly balance
				  if(AverageMonthlyBalance.length()>0){
					  //scrolltoElement(MMS_HomePage.MonthlyLimit);
					  waitForElementPresent(MMS_HomePage.AverageMonthlyBalance,"Per transaction field Present");
					  type(MMS_HomePage.AverageMonthlyBalance, AverageMonthlyBalance, "Per transaction Limit");
					  
				  }
				  
				  // ecommerce 
				 
				  if(EcommerceIndicator.length()>0){
					  //scrolltoElement(MMS_HomePage.RiskApprovalWaive);
					  waitForElementPresent(MMS_HomePage.EcommerceIndicator,"EcommerceIndicator field Present");
					  //selectByVisibleText(MMS_HomePage.Prefferedlanguage, CardAcceptance, "CardAcceptance");
					  
					  click(MMS_HomePage.EcommerceIndicator,"EcommerceIndicator field clicked.");
					  
					  Thread.sleep(2000);
						 // type(MMS_HomePage.GroupMerchant_txt, GroupMerchant, "GroupMerchant");
					   List<WebElement> dropdown= driver.findElements(By.xpath("//div[starts-with(@id,'select2-result-label')]"));
					  
						  for(WebElement e: dropdown) {
						  String a = e.getText();
						      if(a.contains(EcommerceIndicator)) {
						    	  e.click();
						    	  Reporter.reportStep("EcommerceIndicator selected as :"+EcommerceIndicator);
						    	  break;
						      }
						  }
						  
						  Actions  action=new Actions(driver);
							
						  action.moveToElement(driver.findElement(By.id("customer_display"))).doubleClick().perform();
					 
				  }
				  
				  //promo code
				  if(PromoCode.length()>0){
					  //scrolltoElement(MMS_HomePage.MonthlyLimit);
					  waitForElementPresent(MMS_HomePage.PromoCode,"PromoCode field Present");
					  type(MMS_HomePage.PromoCode, PromoCode, "PromoCode");
					  
				  }
	}
	
	//upi details
	public static void fillUPIDefaultDetails(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
		Reporter.reportStep("UPI");
		String Leads_editView_fieldName_less_than_2k = data.get("Leads_editView_fieldName_less_than_2k");
		String Leads_editView_fieldName_greater_than_2k = data.get("Leads_editView_fieldName_greater_than_2k"); 
		
		Actions  action=new Actions(driver);
		
		action.moveToElement(driver.findElement(By.id("Leads_editView_fieldName_international_cr"))).doubleClick().perform();
		scrollDown();
		
		//Leads_editView_fieldName_less_than_2k
		if (Leads_editView_fieldName_less_than_2k.length()>0){
	          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_less_than_2k,"Leads_editView_fieldName_less_than_2k Present");
	          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
	          type(MMS_HomePage.Leads_editView_fieldName_less_than_2k, Leads_editView_fieldName_less_than_2k, "Leads_editView_fieldName_less_than_2k");
	        
	   }
	
		//Leads_editView_fieldName_greater_than_2k
				if (Leads_editView_fieldName_greater_than_2k.length()>0){
			          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_greater_than_2k,"Leads_editView_fieldName_greater_than_2k Present");
			          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
			          type(MMS_HomePage.Leads_editView_fieldName_greater_than_2k, Leads_editView_fieldName_greater_than_2k, "Leads_editView_fieldName_greater_than_2k");
			        
			   }
			
	}
	
	// credit card details
	public static void fillCreditCardCategoryDetails(EventFiringWebDriver driver, Hashtable<String, String> data) throws Throwable {
		// TODO Auto-generated method stub
		Reporter.reportStep("Credit card Category");
		String Leads_editView_fieldName_standard_onus = data.get("Leads_editView_fieldName_standard_onus");
		String Leads_editView_fieldName_standard_domestic_offus = data.get("Leads_editView_fieldName_standard_domestic_offus"); 
		String Leads_editView_fieldName_standard_international_offus = data.get("Leads_editView_fieldName_standard_international_offus");
		String Leads_editView_fieldName_premium_onus = data.get("Leads_editView_fieldName_premium_onus");
		String Leads_editView_fieldName_premium_domestic_offus = data.get("Leads_editView_fieldName_premium_domestic_offus");
		String Leads_editView_fieldName_premium_international_offus = data.get("Leads_editView_fieldName_premium_international_offus");
		String Leads_editView_fieldName_super_premium_onus = data.get("Leads_editView_fieldName_super_premium_onus");
		String Leads_editView_fieldName_super_premium_domestic_offus = data.get("Leads_editView_fieldName_super_premium_domestic_offus");
		String Leads_editView_fieldName_superpremium_int_offus = data.get("Leads_editView_fieldName_superpremium_int_offus");
		
		Actions  action=new Actions(driver);
		
		action.moveToElement(driver.findElement(By.id("Leads_editView_fieldName_international_cr"))).doubleClick().perform();
		scrollDown();
		
		//Leads_editView_fieldName_standard_onus
		if (Leads_editView_fieldName_standard_onus.length()>0){
	          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_standard_onus,"Leads_editView_fieldName_standard_onus Present");
	          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
	          type(MMS_HomePage.Leads_editView_fieldName_standard_onus, Leads_editView_fieldName_standard_onus, "Leads_editView_fieldName_standard_onus");
	        
	   }
	
		//Leads_editView_fieldName_standard_domestic_offus
				if (Leads_editView_fieldName_standard_domestic_offus.length()>0){
			          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_standard_domestic_offus,"Leads_editView_fieldName_standard_domestic_offus Present");
			          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
			          type(MMS_HomePage.Leads_editView_fieldName_standard_domestic_offus, Leads_editView_fieldName_standard_onus, "Leads_editView_fieldName_standard_domestic_offus");
			        
			   }
		
				//Leads_editView_fieldName_standard_domestic_offus
				if (Leads_editView_fieldName_standard_international_offus.length()>0){
			          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_standard_international_offus,"Leads_editView_fieldName_standard_international_offus Present");
			          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
			          type(MMS_HomePage.Leads_editView_fieldName_standard_international_offus, Leads_editView_fieldName_standard_international_offus, "Leads_editView_fieldName_standard_domestic_offus");
			        
			   }
		
				//Leads_editView_fieldName_premium_onus
				if (Leads_editView_fieldName_premium_onus.length()>0){
			          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_premium_onus,"Leads_editView_fieldName_premium_onus Present");
			          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
			          type(MMS_HomePage.Leads_editView_fieldName_premium_onus, Leads_editView_fieldName_standard_international_offus, "Leads_editView_fieldName_premium_onus");
			        
			   }
				
				//Leads_editView_fieldName_premium_domestic_offus
				if (Leads_editView_fieldName_premium_domestic_offus.length()>0){
			          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_premium_domestic_offus,"Leads_editView_fieldName_premium_domestic_offus Present");
			          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
			          type(MMS_HomePage.Leads_editView_fieldName_premium_domestic_offus, Leads_editView_fieldName_premium_domestic_offus, "Leads_editView_fieldName_premium_domestic_offus");
			        
			   }
				
				//Leads_editView_fieldName_premium_international_offus
				if (Leads_editView_fieldName_premium_international_offus.length()>0){
			          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_premium_international_offus,"Leads_editView_fieldName_premium_international_offus Present");
			          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
			          type(MMS_HomePage.Leads_editView_fieldName_premium_international_offus, Leads_editView_fieldName_premium_international_offus, "Leads_editView_fieldName_premium_international_offus");
			        
			   }
				
				//Leads_editView_fieldName_premium_international_offus
				if (Leads_editView_fieldName_super_premium_onus.length()>0){
			          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_super_premium_onus,"Leads_editView_fieldName_super_premium_onus Present");
			          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
			          type(MMS_HomePage.Leads_editView_fieldName_super_premium_onus, Leads_editView_fieldName_super_premium_onus, "Leads_editView_fieldName_super_premium_onus");
			        
			   }
				
				//Leads_editView_fieldName_super_premium_domestic_offus
				if (Leads_editView_fieldName_super_premium_domestic_offus.length()>0){
			          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_super_premium_domestic_offus,"Leads_editView_fieldName_super_premium_domestic_offus Present");
			          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
			          type(MMS_HomePage.Leads_editView_fieldName_super_premium_domestic_offus, Leads_editView_fieldName_super_premium_domestic_offus, "Leads_editView_fieldName_super_premium_domestic_offus");
			        
			   }
				
				//Leads_editView_fieldName_superpremium_int_offus
				if (Leads_editView_fieldName_superpremium_int_offus.length()>0){
			          waitForElementPresent(MMS_HomePage.Leads_editView_fieldName_superpremium_int_offus,"Leads_editView_fieldName_superpremium_int_offus Present");
			          //waitForVisibilityOfElement(MMS_HomePage.MailingAddressLine1,"Mailing Address Line 1 Present");
			          type(MMS_HomePage.Leads_editView_fieldName_superpremium_int_offus, Leads_editView_fieldName_superpremium_int_offus, "Leads_editView_fieldName_superpremium_int_offus");
			        
			   }
			
	}
	*/

	}
