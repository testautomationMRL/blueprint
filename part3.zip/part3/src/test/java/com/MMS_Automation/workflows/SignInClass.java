package com.MMS_Automation.workflows;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.MMS_Automation.testObjects.MMS_SignIn_locator;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class SignInClass extends ActionEngine {

	public String USERID;
	public String password;

	static Logger logger = Logger.getLogger(SignInClass.class.getName());
	
	public void setUSERID(String USERID) {
		this.USERID = USERID;
	}

	public void setpassword(String password) {
		this.password = password;
	}
	
	
	public static boolean specificlogin(String propname, String proppass) throws Throwable

	{
		boolean result = false;
		ImplicitWait();

		String UserName, Password;
		
		UserName = configProps.getProperty(propname);
		Password = configProps.getProperty(proppass);
		String txturl= driver.getCurrentUrl();
		HtmlReportSupport.reportStep("URL launched is:"+txturl);
		
		System.out.println(UserName);
		
		System.out.println(Password);
		HtmlReportSupport.reportStep("Login Credentials_Entry");

		if (waitForElementPresent(MMS_SignIn_locator.Username,"Login Field in Login Page")) {

			logger.info("Login Page loaded succesfully");
             System.out.println("here");
			Reporter.SuccessReport("Axis revamp","Login Page loaded succesfully");

			type(MMS_SignIn_locator.Username, UserName,"UserID Entered Sucessfully");
			waitForJSandJQueryToLoad();
			type(MMS_SignIn_locator.Password, Password,"Password Entered Sucessfully");

			click(MMS_SignIn_locator.loginButton,"Login Button Clicked Successfully");
			waitForJSandJQueryToLoad();

			result = true;
		}
		return result;

	}
	
	public static void logout() throws Throwable {
		Thread.sleep(3000);
		HtmlReportSupport.reportStep("LOGOUT_DETAILS ");
		driver.navigate().refresh();
		Thread.sleep(2000);
		
		
		driver.navigate().refresh();
		// click logout
		Thread.sleep(3000);
		try{
			//if(driver.findElements(By.id("imgLogOut")).size()>0){
				if(driver.findElement(By.cssSelector("span.fa.fa-user")).isDisplayed()){
					Thread.sleep(2000);
					   driver.findElement(By.cssSelector("span.fa.fa-user")).click();
					   //driver.findElement(By.id("menubar_item_right_LBL_SIGN_OUT")).click();
					   driver.findElement(By.xpath("//a[contains(.,'Sign Out')]")).click();
				
					   Reporter.reportStep("Clicked logout button");
			}else{
				
			}
			
			
		}catch(Exception e){
			
		}
	}
}
