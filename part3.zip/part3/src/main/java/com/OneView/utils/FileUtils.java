package com.OneView.utils; 

import java.text.ParseException;
import org.sikuli.script.FindFailed;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileUtils {
	
	public static boolean writeToFile(String fileNamePath, String content) {
		boolean result = false;
		try {

			File file = new File(fileNamePath);

			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			//bw.write(content+"\r\n");
			bw.write(content);
			bw.close();
			result = true;
			System.out.println("Done");

		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
	public static void main(String[] args) throws ParseException, FindFailed, InterruptedException {
		String header = null;
		String meCode = "010037300121";
		header = "63.520080200062" + meCode;
		//header = header + "111099900000" + currencyCode +"463236000000111111000000075";
		header = header + meCode +" 0 201440";
		for(int i=1;i<700;i++){
			header = header + " ";
		}
		header = header + "\r\n";
		
		writeToFile("Results\\batchFiles\\demo.bth", header);
	}

}
